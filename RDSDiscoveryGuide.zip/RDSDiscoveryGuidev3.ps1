﻿#8/16 Add RDS Instance Recommendation Module.
#8/19 Support for Sql 2008 and Sql 2012
#8/27 addedd paramter and RDS option
#9/2 added the Isfree column 
 
Param (
[Parameter()][string]$auth,
[Parameter()][string]$login,
[Parameter()][string]$password,
[Parameter()]$SqlserverEndpoint,
[parameter()]$options 
 
)
Function RDSInstance
{
<#
Mem utlization Less than 80  and Memory on prem  less than 384 G type 
   Cpu utlization greater than 80 scale up 
Memutilization greater than 80 and mempry on prem greater than 384  M type
   if Cpu to Memory difference is >30  x1e
   if Cpu to Memory difference is >15 <29  X1 
   #>
Param(
        [Parameter(Mandatory=$True)]$cpuonprem,
        [Parameter(Mandatory=$True)]$Memoryprem,
        [Parameter(Mandatory=$false)]$cpuutlization,
        [Parameter(Mandatory=$false)]$Memutlization
       )
$class=''
$RDSInstance=''
$rdsval=''
if ($SqlEditionProduct.edition -like 'Enterprise Edition*')
    {       $edition='EE'}

else {$edition ='SE'}    
$version=$SqlEditionProduct.productversion.substring(0,2)


$cpuonprem=[math]::ceiling($cpuonprem/4)
if ($Memoryprem -lt '1025')
{
          if ($cpuonprem  -ge  25)
                  {$class='32xlarge'}
           if ($cpuonprem  -le 24 -and $cpuonprem -gt 16)
                {$class='24xlarge'}
           if ($cpuonprem -le 16 -and $cpuonprem -gt 12)
                {$class='16xlarge'}
           if ($cpuonprem -le 12 -and $cpuonprem -gt 8)
                {$class='12xlarge'}
           if ($cpuonprem -le 8 -and $cpuonprem -gt 4)
                {$class='8xlarge' }
           if ($cpuonprem -le 4 -and $cpuonprem -gt 2)
                {$class='4xlarge' }
           if ($cpuonprem -le 2 -and $cpuonprem -gt 1)
                {$class='2xlarge'}
           if ($cpuonprem -le 1 )
                 {$class='xlarge'}
            if ($cpuonprem -eq 0  )
                {$class='large'}
                }
if ($cpuutlization -ge '80' -and  $Memutlization -ge '80')
      {  $CLASS=switch ($class)
                {'2Xlarge' {'4xlarge'}
                '4Xlarge' {'8xlarge'}
                '8Xlarge' {'12xlarge'}
                '12Xlarge' {'16xlarge'}
                '16Xlarge' {'24xlarge'}
                '24Xlarge' {'32xlarge'}
                '32Xlarge' {'32xlarge'}
          }
          $type='M'
         }
elseif ($cpuutlization -ge '80' -and $Memutlization -le '80')
    {  $CLASS=switch ($class)
                {'2Xlarge' {'4xlarge'}
                '4Xlarge' {'8xlarge'}
                '8Xlarge' {'12xlarge'}
                '12Xlarge' {'16xlarge'}
                '16Xlarge' {'24xlarge'}
                '24Xlarge' {'32xlarge'}
                '32Xlarge' {'32xlarge'}
          }
       $type='G' }
elseif  ($cpuutlization -le '80' -and $Memutlization -ge '80')
    {  #$cpuonprem=$cpuonprem+4
       $type='M' }
  elseif  ($cpuutlization -lt '50' -and $Memutlization -lt '50') #scale Down.
    {   if ($class -ne 'Xlrage')
            {  $CLASS=switch ($class)
                {'2Xlarge' {'xlarge'}
                '4Xlarge' {'2xlarge'}
                '8Xlarge' {'4xlarge'}
                '12Xlarge' {'8xlarge'}
                '16Xlarge' {'12xlarge'}
                '24Xlarge' {'16xlarge'}
                '32Xlarge' {'24xlarge'}
                  }
             }
       $type='G' }
  else {  $type='G'}

if ($Memoryprem -ge 1025 )
{ $class='32xlarge'
}

# this needs to be enable d for RDS.
$file = "C:\RDSDiscoveryGuide\in\RDSSQLInstances.xlsx"
#$sheetName = "Sheet2"
#create new excel COM object
$excel = New-Object -com Excel.Application
#open excel file
$wb = $excel.workbooks.open($file)
#select excel sheet to read data
$sheet=$wb.ActiveSheet #| fl Name # active sheet
$sheetName=$sheet.name
$sheet = $wb.Worksheets.Item($sheetname)
#select total rows
$rowMax = ($sheet.UsedRange.Rows).Count
#create new object with Name, Address, Email properties.
$myData = New-Object -TypeName psobject
$myData | Add-Member -MemberType NoteProperty -Name InstanceName -Value $null
$myData | Add-Member -MemberType NoteProperty -Name version -Value $null
$myData | Add-Member -MemberType NoteProperty -Name edition -Value $null
[System.Collections.ArrayList]$RDSArray = @()
$objTemp=''
     $RdsArray.add($RDSval) | Out-Null
     $val=$null
for ($i = 2; $i -le $rowMax; $i++)
{
    $objTemp = $myData | Select-Object *
     
    #read data from each cell
    $objTemp.InstanceName = $sheet.Cells.Item($i,1).Text
    $objTemp.version = $sheet.Cells.Item($i,2).Text
    $objTemp.edition = $sheet.Cells.Item($i,3).Text
    if ($objTemp.InstanceName -like "*.$class*")
    {
    
    if ($objTemp.edition -eq $edition -and $objTemp.version -match $version)
        {
    $RDSval = [pscustomobject]@{'InstanceName'=$objTemp.InstanceName;'Version'=$version;'Edition'=[string]$edition}
    $RDSArray.add($RDSval) | Out-Null
      $val=$null
    }
   
         }
         }
        
       
if ($Memoryprem -le 1024)
{
   if ($type -eq 'M')
       {       
        $RDSInstance= $RDSArray.instancename| Select-Object -Unique|where {$_ -notlike "db.m*" -and $_ -notlike "db.r3*" -and $_  -notlike "db.r4*" -and $_ -notlike "db.t3*" -and $_ -notlike "db.x1*"-and $_ -notlike "db.x1e*"}
       } 

    elseif ($type -eq 'G')
      {
       $RDSInstance=$RDSArray.instancename| Select-Object -Unique|where {$_ -like "db.m*" }#-and $_ -notlike "db.r3*" -and $_  -notlike "db.r4*" -and $_ -notlike "db.t3*"}
      }
}
Elseif ($Memoryprem -gt 1024)
{
$RDSInstance= $RDSArray.instancename| Select-Object -Unique|where {$_ -like "db.x*" }
  }

$RDSInstance=($RDSInstance -join ",")
$RDSInstance

}
 
 
function L100Questions
{
    $SQLServerLocation=read-host "Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?"
    $License=read-host "Do you currently own any SQL Server licenses that you could bring to the Cloud?Y\N"
        if ($license -eq'Y')
                {
                    $perpetual=read-host "Are you using perpetual license and paying software assurance? Y\N"
                    $subscription=read-host  "Are you using subscription license and paying subscription cost? Y\N"
                    $BYOL=read-host "will you be open to consider using a managed service with License Included, assuming we could make the economics work? Y\N"
                }
    $RDSValue=read-host "Do you see value of having AWS manage your SQL databases? Y\N"
       if ($rdsValue -eq 'Y')
                {
                    $RdsMotivation=read-host "then what are the primary motivations (e.g. cost saving, staff productivity, operational resilience, business agility)?"
                }
    $Migrationtimeframe=Read-host "What is the timeline for SQL Server migration to the Cloud? (Please input an estimated target date in No of Months )"
    return $SQLServerLocation,$License,$perpetual,$subscription,$BYOL,$RDSValue,$RdsMotivation,$Migrationtimeframe
    
}
function SqlserverDiscovery
  {
$sqlVE='select SERVERPROPERTY(''Edition'') AS Edition ,SERVERPROPERTY (''productversion'') AS ProductVersion,SERVERPROPERTY (''IsClustered'') as [Clustered]'
if ($auth -eq 'W') 
{ 
$SQLVEresult=invoke-sqlcmd -serverInstance $server -Database master  -query $sqlVE
}
else 
{
$SQLVEresult=invoke-sqlcmd -serverInstance $server -Database master -user $login -query $sqlVE -password $password
}
return $sqlveresult
      
}#sqlserverdiscovery Function
function L200Discovery
{
    Param(
        [Parameter(Mandatory=$True)]$dbserver,
        [Parameter(Mandatory=$True)]$DBName,
        [Parameter(Mandatory=$false)]$User,
        [Parameter(Mandatory=$false)]$password
       )
 
 
if ($auth -eq 'W') 
{
$sqlLfeatures=invoke-sqlcmd -serverInstance $server -Database master  -inputfile "C:\RDSDiscoveryGuide\In\LimitationQueries.sql" #-query $sql 
}
else 
{
$sqlLfeatures=invoke-sqlcmd -serverInstance $server -Database master -user $login  -inputfile "C:\RDSDiscoveryGuide\In\LimitationQueries.sql" -password $password
}
 
return $sqlLfeatures
}
function Test-SQLConnection
{    
    [OutputType([bool])]
    Param
    (
        [Parameter(Mandatory=$true,
                    ValueFromPipelineByPropertyName=$true,
                    Position=0)]
        $ConnectionString
    )
    try
    {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $sqlConnection.Open();
        $sqlConnection.Close();
        return $true;
    }
    catch
    {
        return $false;
    }
}
    
# Main  Function 
if ($options -eq 'help')
  { write-host " To run the Tool you can either run it using Sql Server Authentication or windows authentication"
    Write-host "   For Sql Server Auth :"
    Write-host "     Rdsdiscoveryguide.exe -Auth s -login ''login'' -password ''password'' -sqlserverendpoint C:\RDSDiscoveryGuide\in\server.txt" -ForegroundColor Green
    Write-host "   For Windows authentication"
    Write-host "     Rdsdiscoveryguide.exe -Auth W -sqlserverendpoint C:\RDSDiscoveryGuide\in\server.txt" -ForegroundColor Green
    Write-host " By the default the tool will run without RDS Recommendation"
    write-host " To include recommendation run this tool with -option rds"
    Write-host " i.e Rdsdiscoveryguide.exe -Auth W -sqlserverendpoint C:\RDSDiscoveryGuide\in\server.txt -options rds" -ForegroundColor Green
    exit

  }
[System.Collections.ArrayList]$RDSArray = @()
        [System.Collections.ArrayList]$ArrayWithHeader = @()
        $RdsArray.add($RDSval) | Out-Null
        $val=$null
         $RDSval=''
         $rdsCustomcompatible='Y'
         $rdscompatible='Y'
$objTemp=''
<#$auth=$args[0]
$login=$args[1]
$password=$args[2]
$SqlserverEndpoint=$args[3]
#>
$copywrite =[char]0x00A9 
Write-Host 'RdsDiscovery Ver 3.00' $copywrite 'BobTheRdsMan.' -ForegroundColor Magenta
Write-Host 'Disclaimer: This Tool is not created or supported by AWS. ' -ForegroundColor Magenta
Write-Host 'Although it is a low risk please make sure  you test in dev before running it in prod.' -ForegroundColor Magenta
Write-Host ' Fo Help run the tool with -options help i.e Rdsdiscoveryguide.exe -options help' -ForegroundColor green
<#if ($auth -eq 'W')
    {
     $SqlserverEndpoint=$login
     $login=' '
    }
    #>
$CpuSql ="SELECT cpu_count AS CPU FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE);"
$MemSql="SELECT  convert(int,value_in_use)/1024 as MaxMemory FROM sys.configurations
WHERE name like 'max server memory%' "
$FileExists=Test-Path -Path $SqlserverEndpoint
if (-Not $FileExists)
  {
   Write-host " Input file  Doesn't exists"
  exit
  } # $fileexists
  
  # L100Questions
   $SQLServerLocation=read-host "Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?"
    $License=read-host "Do you currently own any SQL Server licenses that you could bring to the Cloud?Y\N"
        if ($license -eq'Y')
                {
                    $perpetual=read-host "Are you using perpetual license and paying software assurance? Y\N"
                    $subscription=read-host  "Are you using subscription license and paying subscription cost? Y\N"
                    $BYOL=read-host "will you be open to consider using a managed service with License Included, assuming we could make the economics work? Y\N"
                }
    $RDSValue=read-host "Do you see value of having AWS manage your SQL databases? Y\N"
       if ($rdsValue -eq 'Y')
                {
                    $RdsMotivation=read-host "then what are the primary motivations (e.g. cost saving, staff productivity, operational resilience, business agility)?"
                }
    $Migrationtimeframe=Read-host "What is the timeline for SQL Server migration to the Cloud? (Please input an estimated target date in No of Months )"
$SqlserverEndpoint=Get-Content $SqlserverEndpoint
foreach ($server in $SqlserverEndpoint)
  {
  $rdscompatible='Y'
  $rdsCustomcompatible='Y'
  if ($auth -eq 'W')
       {
            $Conn="Data Source=$server;database=master;Integrated Security=True;" 
        }
    else {
            $Conn="Data Source=$server;User ID=$login;Password=$password;" 
         }
     if (Test-SqlConnection $Conn)
    { 
      if ($auth -eq 'W' )
         {  
            $L200Result=L200Discovery -dbserver $server -DBName master 
            $SqlEditionProduct=SqlserverDiscovery -dbserver $server -DBName master 
            $cpuresult=invoke-sqlcmd -serverInstanc $server -Database master  -query $CpuSql 
            $Memresult=invoke-sqlcmd -serverInstance $server -Database master  -query $Memsql 
            
             }
       Else {
             $L200Result=L200Discovery -dbserver $server -DBName master -user $login -password $password 
             $SqlEditionProduct=SqlserverDiscovery -dbserver $server -DBName master -user $login -password $password 
             $cpuresult=invoke-sqlcmd -serverInstanc $server -Database master -user $login -query $CpuSql -password $password
             $Memresult=invoke-sqlcmd -serverInstance $server -Database master -user $login -query $Memsql -password $password
            }
If ($options -eq 'RDS')
    {
     $Instance=Rdsinstance $cpuresult.CPU $memresult.MAXMemory 50 50
     }
           if ($L200Result.dbcount -eq 'Y' -or $L200Result.islinkedserver -eq 'Y' -or $L200Result.issqlTLShipping -eq 'Y' -or $L200Result.isFilestream -eq 'Y' -or $L200Result.isResouceGov -eq 'Y' -or $L200Result.issqlTranRepl -eq 'Y'`
            -or $l200Result.isextendedProc -eq 'Y'  -or $L200Result.istsqlendpoint -eq 'Y'         -or $L200Result.ispolybase -eq 'Y' -or $L200Result.isfiletable -eq 'Y' -or $L200Result.isbufferpoolextension -eq 'Y'`
              -or $L200Result.isstretchDB -eq 'Y' -or $L200Result.UsedSpaceGB -eq 'Y' -or $L200Result.istrustworthy -eq 'Y' -or $L200Result.Isservertrigger -eq 'Y'`  -or $L200Result.isRMachineLearning -eq 'Y' -or $L200Result.ISPolicyBased -eq 'Y' `
              -or $L200Result.isdqs  -eq 'Y' -or $L200Result.isfree  -eq 'Y') 
           {$rdscompatible='N' }
             else {$rdscompatible='Y'}
    if ($SQLServerLocation -eq 1 )
         { $SQLServerLocation='ONPrem'}
     elseif  ($SQLServerLocation -eq 2 )
          { $SQLServerLocation='EC2'}
     elseif ($SQLServerLocation -eq 3 )
          { $SQLServerLocation='Another Cloud'}
if ( $L200Result.UsedSpaceGB -gt 14901.161) 
    {$rdscompatible='N'
     $rdsCustomcompatible='N'
    }
     if ($rdscompatible -eq 'N')
      {
   
        $val = [pscustomobject]@{'Server Name'=$server;'Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?'=[string]$SQLServerLocation;
                'Do you currently own any SQL Server licenses that you could bring to the Cloud?Y\N'=[string]$License ;
                'Are you using perpetual license and paying software assurance? Y\N'=[string]$perpetual;
                'Are you using subscription license and paying subscription cost? Y\N'=[string]$subscription;
                'will you be open to consider using a managed service with License Included, assuming we could make the economics work? Y\N'=[string]$BYOL;
                'Do you see value of having AWS manage your SQL databases? Y\N'=[string]$RDSValue;
                'Then what are the primary motivations (e.g. cost saving, staff productivity, operational resilience, business agility)?'=[string]$RdsMotivation;
                'What is the timeline for SQL Server migration to the Cloud? (Please input an estimated target date in No of Months )'=[string]$migrationtimeframe;
                'SQL Server Current Edition'=   $SqlEditionProduct.edition;
               'SQL Server current Version'=   $SqlEditionProduct.productversion;
                'SQL Server Replication'= [string]$L200Result.issqlTranRepl;
                'Heterogeneous linked server'=[string]$L200Result.islinkedserver;
                'Database Log Shipping '=[string]$L200Result.issqlTLShipping ;
                'FILESTREAM'=[string]$L200Result.isFilestream;
                'Resource Governor'=[string]$L200Result.isResouceGov;
                'Service Broker Endpoints '=[string]$L200Result.issqlServiceBroker;
                'Non Standard Extended Proc'=[string]$L200Result.isextendedProc;
                'TSQL Endpoints' =[string]$L200Result.istsqlendpoint;
                'PolyBase'=[string]$L200Result.ispolybase;
                'File Tabel'=[string]$L200Result.isfiletable;
                'buffer Pool Extension'=[string]$L200Result.isbufferpoolextension;
                'Stretch DB'=[string]$L200Result.isstretchDB;
                'Trust Worthy On'= [String]$L200Result.istrustworthy;
                'Server Side Trigger'=[string]$L200Result.Isservertrigger;
                'R & Machine Learning'=[string]$L200Result.isRMachineLearning;
                'Data Qulaity Services'=[string]$L200Result.isDQS;
                'Policy Based Management'=[string]$L200Result.ISPolicyBased; 
                'CLR Enabled (only supportd in Ver 2016)'=[String]$L200Result.isCLREnabled;
                ' Free Check'=[string]$L200Result.isfree;
                'DB count Over 100'=[string]$L200Result.dbcount;
                'Total DB Size in GB'=[String]$L200Result.UsedSpaceGB;
                'RDS Compatible' =$rdscompatible;
                'RDS Custom Compatible'=$rdsCustomcompatible;
                'EC2 Compatible'='Y';
                 'Enterprise Level Feature Used '=[string]$L200Result.isEEFeature;
                'Memory'=$memresult.MAXMemory;
               'CPU'   =$cpuresult.CPU;
                 'Instance Type'=[string]$instance;
                'Note'=[string]'***** Plase Note That the Discovery Tool will only detect if a feature is turned on or not ,a feature may be turned on but not used .Use the Queries found in the IN directory to investigate'
                } #@val
    }#if $Rdscompatible
    else 
       {
   
        $val = [pscustomobject]@{'Server Name'=$server;'Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?'=[string]$SQLServerLocation;
                'Do you currently own any SQL Server licenses that you could bring to the Cloud?Y\N'=[string]$License;
                'Are you using perpetual license and paying software assurance? Y\N'=[string]$perpetual;
                'Are you using subscription license and paying subscription cost? Y\N'=[string]$subscription;
                'will you be open to consider using a managed service with License Included, assuming we could make the economics work? Y\N'=[string]$BYOL;
                'Do you see value of having AWS manage your SQL databases? Y\N'=[string]$RDSValue;
                'Then what are the primary motivations (e.g. cost saving, staff productivity, operational resilience, business agility)?'=[string]$RdsMotivation;
                'What is the timeline for SQL Server migration to the Cloud? (Please input an estimated target date in No of Months )'=[string]$migrationtimeframe;
                'SQL Server Current Edition'=   $SqlEditionProduct.edition;
                'SQL Server current Version'=   $SqlEditionProduct.productversion;
                'SQL Server Replication'= [string]$L200Result.issqlTranRepl;
                'Heterogeneous linked server'=[string]$L200Result.islinkedserver;
                'Database Log Shipping '=[string]$L200Result.issqlTLShipping ;
                'FILESTREAM'=[string]$L200Result.isFilestream;
                'Resource Governor'=[string]$L200Result.isResouceGov;
                'Service Broker Endpoints '=[string]$L200Result.issqlServiceBroker;
                'Non Standard Extended Proc'=[string]$L200Result.isextendedProc;
                'TSQL Endpoints' =[string]$L200Result.istsqlendpoint;
                'PolyBase'=[string]$L200Result.ispolybase;
                'File Tabel'=[string]$L200Result.isfiletable;
                'buffer Pool Extension'=[string]$L200Result.isbufferpoolextension;
                'Stretch DB'=[string]$L200Result.isstretchDB;
                'Trust Worthy On'= [String]$L200Result.istrustworthy;
                'Server Side Trigger'=[string]$L200Result.Isservertrigger;
                'R & Machine Learning'=[string]$L200Result.isRMachineLearning;
                'Data Qulaity Services'=[string]$L200Result.isDQS;
                'Policy Based Management'=[string]$L200Result.ISPolicyBased; 
                'CLR Enabled (only supportd in Ver 2016)'=[String]$L200Result.isCLREnabled;
                ' Free Check'=[string]$L200Result.isfree;
                'DB count Over 100'=[string]$L200Result.dbcount;
                'Total DB Size in GB'=[String]$L200Result.UsedSpaceGB;
                'RDS Compatible' =$rdscompatible;
                'RDS Custom Compatible'=$rdsCustomcompatible;
                'EC2 Compatible'='Y';
                'Enterprise Level Feature Used'=[string]$L200Result.isEEFeature;
                'Memory'=$memresult.MAXMemory;
                'CPU'   =$cpuresult.CPU;
                'Instance Type'=[string]$instance
                } #@val
    }#else $Rdscompatible
         
            $ArrayWithHeader.add($val)| Out-Null
              $val=$null
         
    
             }#if
    else 
    {    #write-host $server
          write-host "***** Can't connect to $server"
          }#else
             $ArrayWithHeader|export-Csv -LiteralPath "C:\RDSDiscoveryGuide\out\RdsDiscovery.csv" -NoTypeInformation -Force
       }#foreach
       
     $val = [pscustomobject]@{'Server Name'=''}
             #      $val =[pscustomobject]@{'Note'=$Note}
          $ArrayWithHeader.add($val)| Out-Null
          $val = [pscustomobject]@{'Server Name'='****Note: Instance recommendation is general purpose based on server CPU and Memory capacity , and it is matched by CPU '}
             #      $val =[pscustomobject]@{'Note'=$Note}
          $ArrayWithHeader.add($val)| Out-Null
               $val=$null
            $ArrayWithHeader|export-Csv -LiteralPath "C:\RDSDiscoveryGuide\out\RdsDiscovery.csv" -NoTypeInformation -Force
