﻿#8/11 ading the API call.
#some lceanup still needed.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "RDSTOOLS Parameter Input"
$form.Size = New-Object System.Drawing.Size(500,775)  # Increased form size to accommodate new controls
$form.StartPosition = "CenterScreen"

# Load the logo image
$pictureBox = New-Object System.Windows.Forms.PictureBox
$pictureBox.Location = New-Object System.Drawing.Point(10, 10)
$pictureBox.Size = New-Object System.Drawing.Size(480, 100)
$pictureBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
$pictureBox.Image = [System.Drawing.Image]::FromFile("C:\rdstools\fmvocZ.gif")
$form.Controls.Add($pictureBox)

$label0 = New-Object System.Windows.Forms.Label
$label0.Location = New-Object System.Drawing.Point(10,120)
$label0.Size = New-Object System.Drawing.Size(100,20)
$label0.Text = "Script to Run:"
$form.Controls.Add($label0)

$scriptComboBox = New-Object System.Windows.Forms.ComboBox
$scriptComboBox.Location = New-Object System.Drawing.Point(120,120)
$scriptComboBox.Size = New-Object System.Drawing.Size(100,20)
#$scriptComboBox.Items.AddRange(@("SSAT", "RdsDiscovery", "Health Check", "Help", "Manual"))#, "API Call"))
$scriptComboBox.Items.AddRange(@("SSAT", "RdsDiscovery","Help", "Manual"))#, "API Call"))

$scriptComboBox.SelectedIndex = 1
$form.Controls.Add($scriptComboBox)

$instructionsButton = New-Object System.Windows.Forms.Button
$instructionsButton.Location = New-Object System.Drawing.Point(230, 120)
$instructionsButton.Size = New-Object System.Drawing.Size(75, 23)
$instructionsButton.Text = "Instructions"
$instructionsButton.Add_Click({
    ShowInstructions $scriptComboBox.SelectedItem
})
$form.Controls.Add($instructionsButton)

# Function to show instructions in HTML
function ShowInstructions($selectedScript) {
    $htmlContent = $null
    switch ($selectedScript) {
        "SSAT" {
            $htmlContent = "<h2>SSAT </h2>
                            <p>SQLServerAssessment Tool is a lightweight, free tool that simplifies the assessment of your SQL Server workloads on premise
                             to determine system utilization required for right sizing on Amazon RDS. The tool captures CPU, Memory, IOPS, and Throughput
                             utilization based on a predefined timeframe and makes RDS suggestions on how to right size on AWS. This manual provides guidance 
                             on how to install, use, and troubleshoot the tool.</p>
                            <ul>
                                <li>Collects server metrics (Memory, CPU, IOPS, Throughput)</li>
                                <li>Data is collected every Minute</li>
                                <li>Analyzes the data and provides recommendations and RDS instance sizing </li>
                            </ul>
                            <h3>SSAT instruction </h3>
                            <li>Collection Time: Time to run the collection by default is set to 60 (per minutes)  </li>
                                <li>Endpoint: location of the list of SQL servers in a txt format </li>
                                <li>SA: If SA has been renamed, make sure you enter the new SA login  </li>
                                <li>Options: By default, this field is blank. If you are running the tool for the first time, ensure it remains blank. Otherwise, choose 'C' to clean up jobs, 'T' to terminate the job, 'Dblevel' to generate database-level metrics, or 'upload' if you are manually running the collection. For more details, please refer to the documentation.</li>
                                <li>Admin DB: By default, the tool will create the collection table in the MSDB database. If you prefer to use a different database, please enter its name, ensuring that the database is created beforehand </li>
                                <li>If you are running the tool on RDS, ensure you enter the admin login in the 'SA' box and the database name in the 'DBadmin' field. </li>
                            "
        }
        "RdsDiscovery" {
            $htmlContent = "<h2>RdsDiscovery</h2>
                            <p>The RDS Discovery Tool is a lightweight tool that provides the capability to scan a fleet of on-prem SQL Servers 
                               and does automated checks for 20+ features. It validates supportability of the enabled features
                               on RDS and generates a report which provides recommendations to migrate to RDS, RDS Custom, or EC2 compatible.</p>
                            <ul>
                                <li>Windows or SQL Server Authentication</li>
                                <li>Provides recommendations for migrating to RDS</li>
                                <li>Provides RDS Instances based on allocated CPU/MEM</li>
                            </ul>
                            <h3>RdsDiscovery instruction </h3>
                                <li>Endpoint: location of the list of SQL servers in a txt format </li>
                                <li>Options: By default 'RDS' is selected. It will generate an RDS instance recommendation based on allocated Memory and CPU. </li>
                            "
        }
        "Health Check" {
            $htmlContent = "<h2>Health Check Instructions</h2>
                            <p>The Health Check script will leverage Brent Ozar Scripts. For more details check https://www.brentozar.com/blitz/ </p>
                            <ul>
                                <li>Script supported:</li>
                                <li> sp_Blitz
                                      It checks the health of the entire server no matter which database it's installed in  
                                      (I usually use the master database just because if it's installed in there, then you can call it from any database.)
                                <li> sp_BlitzIndex(coming Soon)
                                <li> sp_BlitzCache(coming Soon) 
                                <li> sp_BlitzFirst(coming soon) </li>
                            </ul>"
        }
        "Support" {
            $htmlContent = "<h2>Support Instructions</h2>
                            <p>This option will convert all created CSV in rdstools\out into JSON and zip them up :</p>
                            <ul>
                                <li>Grab the Zip files and send them to bobtherdsman@gmail.com  </li>
                                <li>Do let me know in the email what Help you are looking for </li>
                                <li>SLA 2-3 Business days. </li>
                                <li>For detailed Amazon Q generated report, do let me know in the email and allow 5 Business days for the report to be generated.</li>
                            </ul>"
        }
        "API Call" {
            $htmlContent = "<h2>API Call Instructions</h2>
                            <p>This feature allows you to make a direct call to the RDS recommendation API.</p>
                            <ul>
                                <li>Enter the required parameters: CPU, Memory, IOPS, Throughput, CPU Utilization, and Memory Utilization</li>
                                <li>Click 'Run' to make the API call and view the recommendations</li>
                                <li>The results will be displayed in a popup window</li>
                            </ul>"
        }
    }

    if ($htmlContent) {
        $browser = New-Object System.Windows.Forms.WebBrowser
        $browser.DocumentText = $htmlContent
        $browser.Dock = "Fill"
        $instructionsForm = New-Object System.Windows.Forms.Form
        $instructionsForm.Text = "Instructions for $selectedScript"
        $instructionsForm.Size = New-Object System.Drawing.Size(500, 400)
        $instructionsForm.Controls.Add($browser)
        $instructionsForm.ShowDialog() | Out-Null
    }
}

$authLabel = New-Object System.Windows.Forms.Label
$authLabel.Location = New-Object System.Drawing.Point(10,150)
$authLabel.Size = New-Object System.Drawing.Size(100,20)
$authLabel.Text = "Auth:"
$form.Controls.Add($authLabel)

$authComboBox = New-Object System.Windows.Forms.ComboBox
$authComboBox.Location = New-Object System.Drawing.Point(120,150)
$authComboBox.Size = New-Object System.Drawing.Size(100,20)
$authComboBox.Items.AddRange(@("S", "W"))
$authComboBox.SelectedIndex = 0
$form.Controls.Add($authComboBox)

$loginLabel = New-Object System.Windows.Forms.Label
$loginLabel.Location = New-Object System.Drawing.Point(10,180)
$loginLabel.Size = New-Object System.Drawing.Size(100,20)
$loginLabel.Text = "Login:"
$form.Controls.Add($loginLabel)

$textBox2 = New-Object System.Windows.Forms.TextBox
$textBox2.Location = New-Object System.Drawing.Point(120,180)
$textBox2.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($textBox2)

$passwordLabel = New-Object System.Windows.Forms.Label
$passwordLabel.Location = New-Object System.Drawing.Point(10,210)
$passwordLabel.Size = New-Object System.Drawing.Size(100,20)
$passwordLabel.Text = "Password:"
$form.Controls.Add($passwordLabel)

$textBox3 = New-Object System.Windows.Forms.TextBox
$textBox3.Location = New-Object System.Drawing.Point(120,210)
$textBox3.Size = New-Object System.Drawing.Size(100,20)
$textBox3.PasswordChar = '*'
$form.Controls.Add($textBox3)

$collectionTimeLabel = New-Object System.Windows.Forms.Label
$collectionTimeLabel.Location = New-Object System.Drawing.Point(10,240)
$collectionTimeLabel.Size = New-Object System.Drawing.Size(100,20)
$collectionTimeLabel.Text = "Collection Time:"
$collectionTimeLabel.Visible = $false
$form.Controls.Add($collectionTimeLabel)

$textBox4 = New-Object System.Windows.Forms.TextBox
$textBox4.Location = New-Object System.Drawing.Point(120,240)
$textBox4.Size = New-Object System.Drawing.Size(100,20)
$textBox4.Text = "60"
$textBox4.Visible = $false
$form.Controls.Add($textBox4)

$serverEndpointLabel = New-Object System.Windows.Forms.Label
$serverEndpointLabel.Location = New-Object System.Drawing.Point(10,270)
$serverEndpointLabel.Size = New-Object System.Drawing.Size(100,20)
$serverEndpointLabel.Text = "Endpoint:"
$form.Controls.Add($serverEndpointLabel)

$textBox5 = New-Object System.Windows.Forms.TextBox
$textBox5.Location = New-Object System.Drawing.Point(120,270)
$textBox5.Size = New-Object System.Drawing.Size(140,20)
$textBox5.Text = "C:\rdstools\in\servers.txt"
$form.Controls.Add($textBox5)

$saLabel = New-Object System.Windows.Forms.Label
$saLabel.Location = New-Object System.Drawing.Point(10,300)
$saLabel.Size = New-Object System.Drawing.Size(100,20)
$saLabel.Text = "SA:"
$saLabel.Visible = $false
$form.Controls.Add($saLabel)

$textBox6 = New-Object System.Windows.Forms.TextBox
$textBox6.Location = New-Object System.Drawing.Point(120,300)
$textBox6.Size = New-Object System.Drawing.Size(100,20)
$textBox6.Text = "sa"
$textBox6.Visible = $false
$form.Controls.Add($textBox6)

$optionsLabel = New-Object System.Windows.Forms.Label
$optionsLabel.Location = New-Object System.Drawing.Point(10,330)
$optionsLabel.Size = New-Object System.Drawing.Size(100,20)
$optionsLabel.Text = "Options:"
$form.Controls.Add($optionsLabel)

$optionsComboBox = New-Object System.Windows.Forms.ComboBox
$optionsComboBox.Location = New-Object System.Drawing.Point(120,330)
$optionsComboBox.Size = New-Object System.Drawing.Size(100,20)
$optionsComboBox.Items.AddRange(@(" ","RDS"))
$optionsComboBox.SelectedIndex = 0
$form.Controls.Add($optionsComboBox)

$checkBox1 = New-Object System.Windows.Forms.CheckBox
$checkBox1.Location = New-Object System.Drawing.Point(10,360)
$checkBox1.Size = New-Object System.Drawing.Size(100,20)
$checkBox1.Text = "Elasticache"
$form.Controls.Add($checkBox1)

$checkBox2 = New-Object System.Windows.Forms.CheckBox
$checkBox2.Location = New-Object System.Drawing.Point(10,390)
$checkBox2.Size = New-Object System.Drawing.Size(100,20)
$checkBox2.Text = "TCOOnly"
$form.Controls.Add($checkBox2)

$label8 = New-Object System.Windows.Forms.Label
$label8.Location = New-Object System.Drawing.Point(10,420)
$label8.Size = New-Object System.Drawing.Size(100,20)
$label8.Text = "Admin DB"
$form.Controls.Add($label8)

$customerLabel = New-Object System.Windows.Forms.Label
$customerLabel.Location = New-Object System.Drawing.Point(10,180)
$customerLabel.Size = New-Object System.Drawing.Size(100,20)
$customerLabel.Text = "Customer Name:"
$form.Controls.Add($customerLabel)

$customerTextBox = New-Object System.Windows.Forms.TextBox
$customerTextBox.Location = New-Object System.Drawing.Point(120,180)
$customerTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($customerTextBox)

$textBox7 = New-Object System.Windows.Forms.TextBox
$textBox7.Location = New-Object System.Drawing.Point(120,420)
$textBox7.Size = New-Object System.Drawing.Size(100,20)
$textBox7.Text = "msdb"
$form.Controls.Add($textBox7)

# Adding new input boxes for API parameters
$cpuLabel = New-Object System.Windows.Forms.Label
$cpuLabel.Location = New-Object System.Drawing.Point(10,450)
$cpuLabel.Size = New-Object System.Drawing.Size(100,20)
$cpuLabel.Text = "CPU:"
$form.Controls.Add($cpuLabel)

$cpuTextBox = New-Object System.Windows.Forms.TextBox
$cpuTextBox.Location = New-Object System.Drawing.Point(120,450)
$cpuTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($cpuTextBox)

$memoryLabel = New-Object System.Windows.Forms.Label
$memoryLabel.Location = New-Object System.Drawing.Point(10,480)
$memoryLabel.Size = New-Object System.Drawing.Size(100,20)
$memoryLabel.Text = "Memory:"
$form.Controls.Add($memoryLabel)

$memoryTextBox = New-Object System.Windows.Forms.TextBox
$memoryTextBox.Location = New-Object System.Drawing.Point(120,480)
$memoryTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($memoryTextBox)

$iopsLabel = New-Object System.Windows.Forms.Label
$iopsLabel.Location = New-Object System.Drawing.Point(10,510)
$iopsLabel.Size = New-Object System.Drawing.Size(100,20)
$iopsLabel.Text = "IOPS:"
$form.Controls.Add($iopsLabel)

$iopsTextBox = New-Object System.Windows.Forms.TextBox
$iopsTextBox.Location = New-Object System.Drawing.Point(120,510)
$iopsTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($iopsTextBox)

$throughputLabel = New-Object System.Windows.Forms.Label
$throughputLabel.Location = New-Object System.Drawing.Point(10,540)
$throughputLabel.Size = New-Object System.Drawing.Size(100,20)
$throughputLabel.Text = "Throughput:"
$form.Controls.Add($throughputLabel)

$throughputTextBox = New-Object System.Windows.Forms.TextBox
$throughputTextBox.Location = New-Object System.Drawing.Point(120,540)
$throughputTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($throughputTextBox)

$cpuUtilLabel = New-Object System.Windows.Forms.Label
$cpuUtilLabel.Location = New-Object System.Drawing.Point(230,450)
$cpuUtilLabel.Size = New-Object System.Drawing.Size(100,20)
$cpuUtilLabel.Text = "CPU Util:"
$form.Controls.Add($cpuUtilLabel)

$cpuUtilTextBox = New-Object System.Windows.Forms.TextBox
$cpuUtilTextBox.Location = New-Object System.Drawing.Point(340,450)
$cpuUtilTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($cpuUtilTextBox)

$memUtilLabel = New-Object System.Windows.Forms.Label
$memUtilLabel.Location = New-Object System.Drawing.Point(230,480)
$memUtilLabel.Size = New-Object System.Drawing.Size(100,20)
$memUtilLabel.Text = "Mem Util:"
$form.Controls.Add($memUtilLabel)

$memUtilTextBox = New-Object System.Windows.Forms.TextBox
$memUtilTextBox.Location = New-Object System.Drawing.Point(340,480)
$memUtilTextBox.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($memUtilTextBox)

# Adding the Youtube Rdstools Demos link
$linkLabel = New-Object System.Windows.Forms.LinkLabel
$linkLabel.Location = New-Object System.Drawing.Point(10,570)
$linkLabel.Size = New-Object System.Drawing.Size(200,20)
$linkLabel.Text = "Youtube Rdstools Demos"
$linkLabel.Links.Add(0, $linkLabel.Text.Length, "https://www.youtube.com/@RdsTools")
$linkLabel.add_LinkClicked({
    param ($sender, $e)
    [System.Diagnostics.Process]::Start($e.Link.LinkData.ToString()) | Out-Null
})
$form.Controls.Add($linkLabel)

# Adding Feedback
$feedbackButton = New-Object System.Windows.Forms.Button
$feedbackButton.Location = New-Object System.Drawing.Point(230, 570)
$feedbackButton.Size = New-Object System.Drawing.Size(75, 32)
$feedbackButton.Text = "Feedback"
$feedbackButton.Add_Click({
    [System.Diagnostics.Process]::Start("https://app.smartsheet.com/b/form/8d23ba71313048b884876896b30a68d9")
})
$form.Controls.Add($feedbackButton)

# Adding GenAI
$GenAIButton = New-Object System.Windows.Forms.Button
$GenAIButton.Location = New-Object System.Drawing.Point(325, 570)
$GenAIButton.Size = New-Object System.Drawing.Size(129, 32)
$GenAIButton.Text = "RDS Recommendation(API CALL)"
$GenAIButton.Enabled = $true  # Setting the button as disabled
$GenAIButton.Add_Click({
    [System.Diagnostics.Process]::Start("https://staging.dnvgbf58smar4.amplifyapp.com/")
})
$form.Controls.Add($GenAIButton)

# Add the logic to download the script
$downloadButton = New-Object System.Windows.Forms.Button
$downloadButton.Location = New-Object System.Drawing.Point(10,600)
$downloadButton.Size = New-Object System.Drawing.Size(100, 23)
$downloadButton.Text = "Download Script"
$downloadButton.Enabled = $true
$downloadButton.Add_Click({
    [System.Diagnostics.Process]::Start("C:\rdstools\manual.ps1")
})
$form.Controls.Add($downloadButton)

# Add the logic to upload the result
$uploadButton = New-Object System.Windows.Forms.Button
$uploadButton.Location = New-Object System.Drawing.Point(120,600)
$uploadButton.Size = New-Object System.Drawing.Size(100, 23)
$uploadButton.Text = "Upload Result"
$uploadButton.Enabled = $true
$uploadButton.Add_Click({
    [System.Diagnostics.Process]::Start("explorer.exe", "C:\rdstools\out")
})
$form.Controls.Add($uploadButton)

# Adding a text box for disclaimer under the link
$disclaimerTextBox = New-Object System.Windows.Forms.TextBox
$disclaimerTextBox.Location = New-Object System.Drawing.Point(10,630)
$disclaimerTextBox.Size = New-Object System.Drawing.Size(480,60)
$disclaimerTextBox.Multiline = $true
$disclaimerTextBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$disclaimerTextBox.Text = "This tool is a personal effort to simplify and accelerate SQL Server migration to RDS. 
This Tool is not supported by AWS. If you have any comments or questions, please reach out to me directly at bobtherdsman@gmail.com."
$form.Controls.Add($disclaimerTextBox)

$button = New-Object System.Windows.Forms.Button
$button.Location = New-Object System.Drawing.Point(10,700)
$button.Size = New-Object System.Drawing.Size(75,23)
$button.Text = "Run"
$button.Add_Click({
    if ($scriptComboBox.SelectedItem -eq "SSAT") {
        $script = "C:\rdstools\ssat.ps1"
        $auth = $authComboBox.SelectedItem
        if ($authComboBox.SelectedItem -eq 'S') { 
            $login = $textBox2.Text
            $password = $textBox3.Text
        }
        $collectiontime = if ($textBox4.Visible) { [int]$textBox4.Text } else { $null }
        $sqlserverendpoint = $textBox5.Text
        $sa = if ($textBox6.Visible) { $textBox6.Text } else { $null }
        $options = $optionsComboBox.SelectedItem
        $Elasticache = if ($checkBox1.Checked) { 'Y' } else { 'N' }
        $TCOOnly = if ($checkBox2.Checked) { 'Y' } else { 'N' }
        $AdminDB = $textBox7.Text

        & $script $auth $login $password $collectiontime $sqlserverendpoint $sa $options $Elasticache $tcoonly $admindb
    } 
    elseif ($scriptComboBox.SelectedItem -eq "RDSDiscovery") {
        $script = "C:\rdstools\RDSDiscoveryGuide.ps1"
        $auth = $authComboBox.SelectedItem
        $login = $textBox2.Text
        $password = $textBox3.Text
        $sqlserverendpoint = $textBox5.Text
        $options = $optionsComboBox.SelectedItem

        & $script $auth $login $password $sqlserverendpoint $options
    } 
    elseif ($scriptComboBox.SelectedItem -eq "Health Check(POC)") {
        $script = "C:\rdstools\perf.ps1"
        $auth = $authComboBox.SelectedItem
        $login = $textBox2.Text
        $password = $textBox3.Text
        $sqlserverendpoint = $textBox5.Text
        $sa = if ($textBox6.Visible) { $textBox6.Text } else { $null }
        $AdminDB = $textBox7.Text

        & $script $auth $login $password $sqlserverendpoint $sa $admindb
    } 
    elseif ($scriptComboBox.SelectedItem -eq "Help") {
        $script = "C:\rdstools\help.ps1"
        $customer = $customerTextBox.Text

        & $script $customer
        Write-Host "Email the Zip file $customer.zip found in c:\rdstools\out back to bobtherdsman@gmail.com"
    } 
    elseif ($scriptComboBox.SelectedItem -eq "Manual") {
        [System.Diagnostics.Process]::Start("C:\RDSTOOLS\Queries\stanadlonescollection_full.sql")
    } 
    elseif ($scriptComboBox.SelectedItem -eq "API Call") {
        $cpu = $cpuTextBox.Text
        $memory = $memoryTextBox.Text
        $iops = $iopsTextBox.Text
        $throughput = $throughputTextBox.Text
        $cpuUtil = $cpuUtilTextBox.Text
        $memUtil = $memUtilTextBox.Text

        $apiUrl = "https://u52tgo3yzg.execute-api.us-east-1.amazonaws.com/prod//rds-recommendation?cpu=$cpu&memory=$memory&iops=$iops&throughput=$throughput&cpu_utilization=$cpuUtil&mem_utilization=$memUtil"
        
        try {
            $response = Invoke-RestMethod -Uri $apiUrl -Method Get
            [System.Windows.Forms.MessageBox]::Show(($response | ConvertTo-Json -Depth 5), "API Call Result", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "API Call Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
    }
})

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Location = New-Object System.Drawing.Point(100,700)
$stopButton.Size = New-Object System.Drawing.Size(75,23)
$stopButton.Text = "Stop"
$stopButton.Add_Click({
    $form.Close()
})

$form.Controls.Add($button)
$form.Controls.Add($stopButton)

function scriptComboBox_SelectedIndexChanged {
  $loginEnabled = $authComboBox.SelectedItem -eq "S"
    if ($scriptComboBox.SelectedItem -eq "RdsDiscovery") {
        $customerLabel.Visible = $false
        $authLabel.Visible = $true
        $authComboBox.Visible = $true
        
        $passwordLabel.Visible = $loginEnabled
        $textBox3.Visible = $loginEnabled
        
        $loginLabel.Visible = $loginEnabled
        $textBox2.Visible = $loginEnabled

        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $false
        $textBox6.Visible = $false
        $optionsLabel.Visible = $true
        $optionsComboBox.Visible = $true
        $optionsComboBox.Items.Clear()
        $optionsComboBox.Items.AddRange(@(" ","RDS"))
        $optionsComboBox.SelectedItem = "RDS"
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $false
        $textBox7.Visible = $false
        $downloadButton.Enabled = $false
        $uploadButton.Enabled = $false
        $cpuLabel.Visible = $false
        $cpuTextBox.Visible = $false
        $memoryLabel.Visible = $false
        $memoryTextBox.Visible = $false
        $iopsLabel.Visible = $false
        $iopsTextBox.Visible = $false
        $throughputLabel.Visible = $false
        $throughputTextBox.Visible = $false
        $cpuUtilLabel.Visible = $false
        $cpuUtilTextBox.Visible = $false
        $memUtilLabel.Visible = $false
        $memUtilTextBox.Visible = $false
    }
elseif ($scriptComboBox.SelectedItem -eq "SSAT") {
        $customerLabel.Visible = $false
        $authLabel.Visible = $true
        $authComboBox.Visible = $true
      <#  $loginLabel.Visible = $loginEnabled
        $textBox2.Visible = $loginEnabled#>
        $passwordLabel.Visible = $loginEnabled
        $textBox3.Visible = $loginEnabled
        $collectionTimeLabel.Visible = $true
        $textBox4.Visible = $true
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $true
        $textBox6.Visible = $true
        $optionsLabel.Visible = $true
        $optionsComboBox.Visible = $true
        $optionsComboBox.Items.Clear()
        $optionsComboBox.Items.AddRange(@(" ","C", "T", "dblevel", "upload"))
        $optionsComboBox.SelectedItem = " "
        $checkBox1.Visible = $true
        $checkBox2.Visible = $false
        $label8.Visible = $true
        $textBox7.Visible = $true
        $downloadButton.Enabled = $false
        $uploadButton.Enabled = $false
        $cpuLabel.Visible = $false
        $cpuTextBox.Visible = $false
        $memoryLabel.Visible = $false
        $memoryTextBox.Visible = $false
        $iopsLabel.Visible = $false
        $iopsTextBox.Visible = $false
        $throughputLabel.Visible = $false
        $throughputTextBox.Visible = $false
        $cpuUtilLabel.Visible = $false
        $cpuUtilTextBox.Visible = $false
        $memUtilLabel.Visible = $false
        $memUtilTextBox.Visible = $false
    } elseif ($scriptComboBox.SelectedItem -eq "Health Check")  {
        $customerLabel.Visible = $false
        $authLabel.Visible = $true
        $authComboBox.Visible = $true
        $loginLabel.Visible = $true
        $textBox2.Visible = $true
        $passwordLabel.Visible = $true
        $textBox3.Visible = $true
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $true
        $textBox6.Visible = $true
        $optionsLabel.Visible = $false
        $optionsComboBox.Visible = $false
        $optionsComboBox.SelectedItem = " "
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $true
        $textBox7.Visible = $true
        $downloadButton.Enabled = $false
        $uploadButton.Enabled = $false
        $cpuLabel.Visible = $false
        $cpuTextBox.Visible = $false
        $memoryLabel.Visible = $false
        $memoryTextBox.Visible = $false
        $iopsLabel.Visible = $false
        $iopsTextBox.Visible = $false
        $throughputLabel.Visible = $false
        $throughputTextBox.Visible = $false
        $cpuUtilLabel.Visible = $false
        $cpuUtilTextBox.Visible = $false
        $memUtilLabel.Visible = $false
        $memUtilTextBox.Visible = $false
    } elseif ($scriptComboBox.SelectedItem -eq "Help")  {
        $customerLabel.Visible = $true
        $authLabel.Visible = $false
        $authComboBox.Visible = $false
        $loginLabel.Visible = $false
        $textBox2.Visible = $false
        $passwordLabel.Visible = $false
        $textBox3.Visible = $false
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $false
        $textBox5.Visible = $false
        $saLabel.Visible = $false
        $textBox6.Visible = $false
        $optionsLabel.Visible = $false
        $optionsComboBox.Visible = $false
        $optionsComboBox.Items.Clear()
        $optionsComboBox.Items.AddRange(@(" ","C", "T", "dblevel", "upload"))
        $optionsComboBox.SelectedItem = " "
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $false
        $textBox7.Visible = $false
        $downloadButton.Enabled = $false
        $uploadButton.Enabled = $false
        $cpuLabel.Visible = $false
        $cpuTextBox.Visible = $false
        $memoryLabel.Visible = $false
        $memoryTextBox.Visible = $false
        $iopsLabel.Visible = $false
        $iopsTextBox.Visible = $false
        $throughputLabel.Visible = $false
        $throughputTextBox.Visible = $false
        $cpuUtilLabel.Visible = $false
        $cpuUtilTextBox.Visible = $false
        $memUtilLabel.Visible = $false
        $memUtilTextBox.Visible = $false
    } elseif ($scriptComboBox.SelectedItem -eq "Manual") {
        $customerLabel.Visible = $false
        $authLabel.Visible = $false
        $authComboBox.Visible = $false
        $loginLabel.Visible = $true
        $textBox2.Visible = $false
        $passwordLabel.Visible = $false
        $textBox3.Visible = $false
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $false
        $textBox5.Visible = $false
        $saLabel.Visible = $false
        $textBox6.Visible = $false
        $optionsLabel.Visible = $false
        $optionsComboBox.Visible = $false
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $false
        $textBox7.Visible = $false
        $downloadButton.Enabled = $true
        $uploadButton.Enabled = $true
        $cpuLabel.Visible = $false
        $cpuTextBox.Visible = $false
        $memoryLabel.Visible = $false
        $memoryTextBox.Visible = $false
        $iopsLabel.Visible = $false
        $iopsTextBox.Visible = $false
        $throughputLabel.Visible = $false
        $throughputTextBox.Visible = $false
        $cpuUtilLabel.Visible = $false
        $cpuUtilTextBox.Visible = $false
        $memUtilLabel.Visible = $false
        $memUtilTextBox.Visible = $false
    } elseif ($scriptComboBox.SelectedItem -eq "API Call") {
        $customerLabel.Visible = $false
        $authLabel.Visible = $false
        $authComboBox.Visible = $false
        $loginLabel.Visible = $false
        $textBox2.Visible = $false
        $passwordLabel.Visible = $false
        $textBox3.Visible = $false
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $false
        $textBox5.Visible = $false
        $saLabel.Visible = $false
        $textBox6.Visible = $false
        $optionsLabel.Visible = $false
        $optionsComboBox.Visible = $false
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $false
        $textBox7.Visible = $false
        $downloadButton.Enabled = $false
        $uploadButton.Enabled = $false
        $cpuLabel.Visible = $true
        $cpuTextBox.Visible = $true
        $memoryLabel.Visible = $true
        $memoryTextBox.Visible = $true
        $iopsLabel.Visible = $true
        $iopsTextBox.Visible = $true
        $throughputLabel.Visible = $true
        $throughputTextBox.Visible = $true
        $cpuUtilLabel.Visible = $true
        $cpuUtilTextBox.Visible = $true
        $memUtilLabel.Visible = $true
        $memUtilTextBox.Visible = $true
    }
}

$authComboBox.Add_SelectedIndexChanged({
    if ($scriptComboBox.SelectedItem -eq "RdsDiscovery" -or $scriptComboBox.SelectedItem -eq "SSAT") {
        $loginEnabled = $authComboBox.SelectedItem -eq "S"
        $loginLabel.Visible = $loginEnabled
        $textBox2.Visible = $loginEnabled
        $customerLabel.Visible = $false
        $customerTextBox.Visible = $false
        $passwordLabel.Visible = $loginEnabled
        $textBox3.Visible = $loginEnabled
    
        scriptComboBox_SelectedIndexChanged
    }
})

$scriptComboBox.Add_SelectedIndexChanged([System.EventHandler] { scriptComboBox_SelectedIndexChanged })

# Trigger the event to set the default visibility
scriptComboBox_SelectedIndexChanged

$form.ShowDialog() | Out-Null