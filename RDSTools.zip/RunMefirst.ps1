﻿#6/2 add instruction
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "RDSTOOLS Parameter Input"
$form.Size = New-Object System.Drawing.Size(500,650)
$form.StartPosition = "CenterScreen"

# Load the logo image
$pictureBox = New-Object System.Windows.Forms.PictureBox
$pictureBox.Location = New-Object System.Drawing.Point(10, 10)
$pictureBox.Size = New-Object System.Drawing.Size(480, 100)
$pictureBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage
$pictureBox.Image = [System.Drawing.Image]::FromFile("C:\rdstools\rdstools.png")
$form.Controls.Add($pictureBox)

$label0 = New-Object System.Windows.Forms.Label
$label0.Location = New-Object System.Drawing.Point(10,120)
$label0.Size = New-Object System.Drawing.Size(100,20)
$label0.Text = "Script to Run:"
$form.Controls.Add($label0)

$scriptComboBox = New-Object System.Windows.Forms.ComboBox
$scriptComboBox.Location = New-Object System.Drawing.Point(120,120)
$scriptComboBox.Size = New-Object System.Drawing.Size(100,20)
$scriptComboBox.Items.AddRange(@("SSAT", "RdsDiscovery","Health Check"))
$scriptComboBox.SelectedIndex = 1
$form.Controls.Add($scriptComboBox)


$instructionsButton = New-Object System.Windows.Forms.Button
$instructionsButton.Location = New-Object System.Drawing.Point(230, 120)
$instructionsButton.Size = New-Object System.Drawing.Size(75, 23)
$instructionsButton.Text = "Instructions"
$instructionsButton.Add_Click({
    ShowInstructions $scriptComboBox.SelectedItem
})
$form.Controls.Add($instructionsButton)

# Function to show instructions in HTML
function ShowInstructions($selectedScript) {
    $htmlContent = $null
    switch ($selectedScript) {
        "SSAT" {
                       $htmlContent = "<h2>SSAT </h2>
                            <p>SQLServerAssessment Tool is a lightweight, free tool that simplifies the assessment of your SQL Server workloads on premise
                             to determine system utilization required for right sizing on Amazon RDS. The tool captures CPU, Memory, IOPS, and Throughput
                             utilization based on a predefined timeframe and makes RDS suggestions on how to right size on AWS. This manual provides guidance 
                             on how to install, use, and troubleshoot the tool.</p>
                            <ul>
                                <li>Collects server metrcis (Memory,CPU,IOPS,Throughput'</li>
                                <li>Data is coolected every Minute'</li>
                                <li>Analyzes the data and provides recommendations and RDS instance sizing </li>
                            </ul>
                            <h3>SSAT instruction </h3>
                            <li>collection Time :Time to run the collection by drault is it iset to 60 ( per minutes)  </li>
                                <li>Endpoint :location of the list of sql server in a txt format </li>
                                <li>SA :If SA has been renamed  make sure you enter the new SA login  </li>
                                <Li>Options: By default, this field is blank. If you are running the tool for the first time, ensure it remains blank. Otherwise, choose 'C' to clean up jobs, 'T' to terminate the job, 'Dblevel' to generate database-level metrics, or 'upload' if you are manually running the collection. For more details, please refer to the documentation.</li>
                                <li>Admin DB :By default, the tool will create the collection table in the MSDB database. If you prefer to use a different database, please enter its name, ensuring that the database is created beforehand </li>
                                <li>If you are running the tool on RDS, ensure you enter the admin login in the 'SA' box and the database name in the 'DBadmin' field. </li>
                                

                                                                                        
                            "
        }
        "RdsDiscovery" {
            $htmlContent = "<h2>RdsDiscovery</h2>
                            <p>The RDS Discovery Tool is a lightweight tool that provides the capability to scan a fleet of on-prem SQL Servers 
                               and does automated checks for 20+ features. It validates supportability of the enabled features
                               on RDS and generates a report which provides recommendations to migrate to RDS, RDS Custom, or EC2 compatible.</p>
                            <ul>
                                <li>Windows or Sql serer Authentication</li>
                                <li>Provides recommendations for migrating to RDS</li>
                                <li>Provied RDS Instances based on allocated CPU/MEM</li>
                            </ul>
                            <h3>RdsDiscovery instruction </h3>
                                <li>Endpoint :location of the list of sql server in a txt format </li>
                                <Li> Options:  By default 'RDS' is selected it will generate an rds instance recommendation based on allocated Memoey and cpu. </li>
                            
                            "
        }
        "Health Check" {
            $htmlContent = "<h2>Health Check Instructions</h2>
                            <p>The Health Check script performs the following tasks:</p>
                            <ul>
                                <li>Evaluates the performance and health of the RDS instance</li>
                                <li>Provides recommendations for improving performance and reducing costs</li>
                            </ul>"
        }
    }

    if ($htmlContent) {
        $browser = New-Object System.Windows.Forms.WebBrowser
        $browser.DocumentText = $htmlContent
        $browser.Dock = "Fill"
        $instructionsForm = New-Object System.Windows.Forms.Form
        $instructionsForm.Text = "Instructions for $selectedScript"
        $instructionsForm.Size = New-Object System.Drawing.Size(500, 400)
        $instructionsForm.Controls.Add($browser)
        $instructionsForm.ShowDialog() | Out-Null
    }
}

#instrunction/End
















$authLabel = New-Object System.Windows.Forms.Label
$authLabel.Location = New-Object System.Drawing.Point(10,150)
$authLabel.Size = New-Object System.Drawing.Size(100,20)
$authLabel.Text = "Auth:"
$form.Controls.Add($authLabel)

$authComboBox = New-Object System.Windows.Forms.ComboBox
$authComboBox.Location = New-Object System.Drawing.Point(120,150)
$authComboBox.Size = New-Object System.Drawing.Size(100,20)
$authComboBox.Items.AddRange(@("S", "W"))
$authComboBox.SelectedIndex = 0
$form.Controls.Add($authComboBox)

$loginLabel = New-Object System.Windows.Forms.Label
$loginLabel.Location = New-Object System.Drawing.Point(10,180)
$loginLabel.Size = New-Object System.Drawing.Size(100,20)
$loginLabel.Text = "Login:"
$form.Controls.Add($loginLabel)

$textBox2 = New-Object System.Windows.Forms.TextBox
$textBox2.Location = New-Object System.Drawing.Point(120,180)
$textBox2.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($textBox2)

$passwordLabel = New-Object System.Windows.Forms.Label
$passwordLabel.Location = New-Object System.Drawing.Point(10,210)
$passwordLabel.Size = New-Object System.Drawing.Size(100,20)
$passwordLabel.Text = "Password:"
$form.Controls.Add($passwordLabel)

$textBox3 = New-Object System.Windows.Forms.TextBox
$textBox3.Location = New-Object System.Drawing.Point(120,210)
$textBox3.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($textBox3)

$collectionTimeLabel = New-Object System.Windows.Forms.Label
$collectionTimeLabel.Location = New-Object System.Drawing.Point(10,240)
$collectionTimeLabel.Size = New-Object System.Drawing.Size(100,20)
$collectionTimeLabel.Text = "Collection Time:"
$collectionTimeLabel.Visible = $false
$form.Controls.Add($collectionTimeLabel)

$textBox4 = New-Object System.Windows.Forms.TextBox
$textBox4.Location = New-Object System.Drawing.Point(120,240)
$textBox4.Size = New-Object System.Drawing.Size(100,20)
$textBox4.Text = "60"
$textBox4.Visible = $false
$form.Controls.Add($textBox4)

$serverEndpointLabel = New-Object System.Windows.Forms.Label
$serverEndpointLabel.Location = New-Object System.Drawing.Point(10,270)
$serverEndpointLabel.Size = New-Object System.Drawing.Size(100,20)
$serverEndpointLabel.Text = "Endpoint:"
$form.Controls.Add($serverEndpointLabel)

$textBox5 = New-Object System.Windows.Forms.TextBox
$textBox5.Location = New-Object System.Drawing.Point(120,270)
$textBox5.Size = New-Object System.Drawing.Size(140,20)
$textBox5.Text = "C:\rdstools\in\servers.txt"
$form.Controls.Add($textBox5)

$saLabel = New-Object System.Windows.Forms.Label
$saLabel.Location = New-Object System.Drawing.Point(10,300)
$saLabel.Size = New-Object System.Drawing.Size(100,20)
$saLabel.Text = "SA:"
$saLabel.Visible = $false
$form.Controls.Add($saLabel)

$textBox6 = New-Object System.Windows.Forms.TextBox
$textBox6.Location = New-Object System.Drawing.Point(120,300)
$textBox6.Size = New-Object System.Drawing.Size(100,20)
$textBox6.Text = "sa"
$textBox6.Visible = $false
$form.Controls.Add($textBox6)

$optionsLabel = New-Object System.Windows.Forms.Label
$optionsLabel.Location = New-Object System.Drawing.Point(10,330)
$optionsLabel.Size = New-Object System.Drawing.Size(100,20)
$optionsLabel.Text = "Options:"
$form.Controls.Add($optionsLabel)

$optionsComboBox = New-Object System.Windows.Forms.ComboBox
$optionsComboBox.Location = New-Object System.Drawing.Point(120,330)
$optionsComboBox.Size = New-Object System.Drawing.Size(100,20)
$optionsComboBox.Items.AddRange(@(" ","RDS"))
#$optionsComboBox.Items.AddRange(@(" "))
$optionsComboBox.SelectedIndex = 0
$form.Controls.Add($optionsComboBox)

$checkBox1 = New-Object System.Windows.Forms.CheckBox
$checkBox1.Location = New-Object System.Drawing.Point(10,360)
$checkBox1.Size = New-Object System.Drawing.Size(100,20)
$checkBox1.Text = "Elasticache"
$form.Controls.Add($checkBox1)

$checkBox2 = New-Object System.Windows.Forms.CheckBox
$checkBox2.Location = New-Object System.Drawing.Point(10,390)
$checkBox2.Size = New-Object System.Drawing.Size(100,20)
$checkBox2.Text = "TCOOnly"
$form.Controls.Add($checkBox2)

$label8 = New-Object System.Windows.Forms.Label
$label8.Location = New-Object System.Drawing.Point(10,420)
$label8.Size = New-Object System.Drawing.Size(100,20)
$label8.Text = "Admin DB"
$form.Controls.Add($label8)

$textBox7 = New-Object System.Windows.Forms.TextBox
$textBox7.Location = New-Object System.Drawing.Point(120,420)
$textBox7.Size = New-Object System.Drawing.Size(100,20)
$textBox7.Text = "msdb"
$form.Controls.Add($textBox7)

# Adding the Youtube Rdstools Demos link
$linkLabel = New-Object System.Windows.Forms.LinkLabel
$linkLabel.Location = New-Object System.Drawing.Point(10,480)
$linkLabel.Size = New-Object System.Drawing.Size(200,20)
$linkLabel.Text = "Youtube Rdstools Demos"
$linkLabel.Links.Add(0, $linkLabel.Text.Length, "https://www.youtube.com/@RdsTools")
$linkLabel.add_LinkClicked({
    param ($sender, $e)
    [System.Diagnostics.Process]::Start($e.Link.LinkData.ToString()) | Out-Null
})
$form.Controls.Add($linkLabel)

# Adding a text box for disclaimer under the link
$disclaimerTextBox = New-Object System.Windows.Forms.TextBox
$disclaimerTextBox.Location = New-Object System.Drawing.Point(10,510)
$disclaimerTextBox.Size = New-Object System.Drawing.Size(480,60)
$disclaimerTextBox.Multiline = $true
$disclaimerTextBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$disclaimerTextBox.Text = "This tool is a personal effort to simplify and accelerate SQL Server migration to RDS. 
This Tool is not supported by AWS.but If you have any comments or questions, please reach out to me directly at bobtherdsman@gmail.com."
$form.Controls.Add($disclaimerTextBox)
#This tool is a personal effort to simplify and accelerate SQL Server migration to RDS. It is not supported by AWS. If you have any comments or questions, please reach out to me directly at bobtherdsman@gmail.com.


$button = New-Object System.Windows.Forms.Button
$button.Location = New-Object System.Drawing.Point(10,580)
$button.Size = New-Object System.Drawing.Size(75,23)
$button.Text = "Run"
$button.Add_Click({
    if ($scriptComboBox.SelectedItem -eq "SSAT") {
        $script="C:\rdstools\ssat.ps1"
        $auth = $authComboBox.SelectedItem
        if ( $authComboBox.SelectedItem -eq 'S') { 
        $login = $textBox2.Text
        $password = $textBox3.Text
        }
        $collectiontime = if ($textBox4.Visible) { [int]$textBox4.Text } else { $null }
        $sqlserverendpoint = $textBox5.Text
        $sa = if ($textBox6.Visible) { $textBox6.Text } else { $null }
        $options = $optionsComboBox.SelectedItem
        $Elasticache = if ($checkBox1.Checked) { 'Y' } else { 'N' }
        $TCOOnly = if ($checkBox2.Checked) { 'Y' } else { 'N' }
        $AdminDB = $textBox7.Text

        & $script $auth $login $password $collectiontime $sqlserverendpoint $sa $options $Elasticache $tcoonly $admindb
    } elseif ($scriptComboBox.SelectedItem -eq "RDSDiscovery") {
        $script="C:\rdstools\RDSDiscoveryGuide.ps1"
        $auth = $authComboBox.SelectedItem
        $login = $textBox2.Text
        $password = $textBox3.Text
        $sqlserverendpoint = $textBox5.Text
        $options = $optionsComboBox.SelectedItem

        & $script $auth $login $password $sqlserverendpoint $options

    }Elseif ($scriptComboBox.SelectedItem -eq "Health Check") {
        $script="C:\rdstools\perf.ps1"
        $auth = $authComboBox.SelectedItem
        $login = $textBox2.Text
        $password = $textBox3.Text
        #$collectiontime = if ($textBox4.Visible) { [int]$textBox4.Text } else { $null }
        $sqlserverendpoint = $textBox5.Text
        $sa = if ($textBox6.Visible) { $textBox6.Text } else { $null }
        #$options = $optionsComboBox.SelectedItem
        #$Elasticache = if ($checkBox1.Checked) { 'Y' } else { 'N' }
        #$TCOOnly = if ($checkBox2.Checked) { 'Y' } else { 'N' }
        $AdminDB = $textBox7.Text

        & $script $auth $login $password $collectiontime $sqlserverendpoint $sa $options $Elasticache $tcoonly $admindb
}
})

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Location = New-Object System.Drawing.Point(100,580)
$stopButton.Size = New-Object System.Drawing.Size(75,23)
$stopButton.Text = "Stop"
$stopButton.Add_Click({
    $form.Close()
})

$form.Controls.Add($button)
$form.Controls.Add($stopButton)

function scriptComboBox_SelectedIndexChanged {
    if ($scriptComboBox.SelectedItem -eq "RdsDiscovery") {
        $authLabel.Visible = $true
        $authComboBox.Visible = $true
        $loginLabel.Visible = $true
        $textBox2.Visible = $true
        $passwordLabel.Visible = $true
        $textBox3.Visible = $true
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $false
        $textBox6.Visible = $false
        $optionsLabel.Visible = $true
        $optionsComboBox.Visible = $true
        $optionsComboBox.Items.Clear() # Clear the existing items
        $optionsComboBox.Items.AddRange(@(" ","RDS"))
        $optionsComboBox.SelectedItem = "RDS"
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $false
        $textBox7.Visible = $false
    } elseif ($scriptComboBox.SelectedItem -eq "SSAT")  {
        $authLabel.Visible = $true
        $authComboBox.Visible = $true
        $loginLabel.Visible = $true
        $textBox2.Visible = $true
        $passwordLabel.Visible = $true
        $textBox3.Visible = $true
        $collectionTimeLabel.Visible = $true
        $textBox4.Visible = $true
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $true
        $textBox6.Visible = $true
        $optionsLabel.Visible = $true
        $optionsComboBox.Visible = $true
        $optionsComboBox.Items.Clear() # Clear the existing items
        $optionsComboBox.Items.AddRange(@(" ","C", "T", "dblevel", "upload"))
        $optionsComboBox.SelectedItem = " " # Set options to blank
        $checkBox1.Visible = $true
        $checkBox2.Visible = $false #tcoonly
        $label8.Visible = $true
        $textBox7.Visible = $true

    } elseif ($scriptComboBox.SelectedItem -eq "Health Check")  {
    [System.Windows.Forms.MessageBox]::Show("The Health Check feature is coming soon.", "Upcoming Feature", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
       <# $authLabel.Visible = $true
        $authComboBox.Visible = $true
        $loginLabel.Visible = $true
        $textBox2.Visible = $true
        $passwordLabel.Visible = $true
        $textBox3.Visible = $true
        $collectionTimeLabel.Visible = $false
        $textBox4.Visible = $false
        $serverEndpointLabel.Visible = $true
        $textBox5.Visible = $true
        $saLabel.Visible = $true
        $textBox6.Visible = $true
        $optionsLabel.Visible = $false
        $optionsComboBox.Visible = $false
        $optionsComboBox.SelectedItem = " " # Set options to blank
        $checkBox1.Visible = $false
        $checkBox2.Visible = $false
        $label8.Visible = $true
        $textBox7.Visible = $true#>

    }
}
<#
added 630 to hide the login and passwrod if W is selected 
#>
$authComboBox.Add_SelectedIndexChanged({
    if ($authComboBox.SelectedItem -eq "W") {
        $loginLabel.Visible = $false
        $textBox2.Visible = $false
        $passwordLabel.Visible = $false
        $textBox3.Visible = $false
    } else {
        $loginLabel.Visible = $true
        $textBox2.Visible = $true
        $passwordLabel.Visible = $true
        $textBox3.Visible = $true
    }
})
$scriptComboBox.Add_SelectedIndexChanged([System.EventHandler] { scriptComboBox_SelectedIndexChanged })


# Trigger the event to set the default visibility
scriptComboBox_SelectedIndexChanged

$form.ShowDialog() | Out-Null
