﻿Param (
  [Parameter()][string]$auth,
  [Parameter()][string]$login,
  [Parameter()][string]$password,
  [Parameter()][string]$SqlserverEndpoint,
  [Parameter()][string]$options,
  [Parameter()][string]$babelfish
)

# Set default values after parameter declaration
if (-not $SqlserverEndpoint) { $SqlserverEndpoint = 'c:\rdstools\in\servers.txt' }
if (-not $options) { $options = 'RDS' }
if (-not $babelfish) { $babelfish = 'N' }

Function ElasticacheAssessment
{
  Param(
    [Parameter(Mandatory = $True)]$dbserver,
    [Parameter(Mandatory = $True)]$DBName,
    [Parameter(Mandatory = $False)]$User,
    [Parameter(Mandatory = $False)]$Password
  )
  
$ReadOverall=' declare @readoverwrite char(1)
                 WITH Read_WriteIO (execution_count,query_text,[Total Logical Reads (MB)],TotalLogicalRead,TotalPhysicalRead,total_logical_writes,total_grant_kb)
                    as 
                        ( SELECT    qs.execution_count,query_text = SUBSTRING( qt.text, qs.statement_start_offset / 2 + 1
                        ,( CASE WHEN qs.statement_end_offset = -1 THEN LEN( CONVERT( nvarchar(MAX), qt.text )) * 2
                            ELSE qs.statement_end_offset
                            END - qs.statement_start_offset ) / 2 )
                        ,(qs.total_logical_reads)*8/1024.0 AS [Total Logical Reads (MB)],
                            qs.total_logical_reads as [TotalLogicalRead],qs.total_physical_reads as TotalPhysicalRead,
                            qs.total_logical_writes, qs.total_grant_kb  
                                FROM   sys.dm_exec_query_stats               AS qs
                                CROSS APPLY sys.dm_exec_sql_text( qs.sql_handle ) AS qt
                            ), ReadOverWrite as
                                (
                                    select  top 50 execution_count, query_text, TotalLogicalRead,total_logical_writes,
                                    ([Total Logical Reads (MB)]*100)/(SELECT sum([Total Logical Reads (MB)]) from Read_WriteIO  ) as overallreadweight 
                                    ,((TotalLogicalRead*100)/nullif(TotalLogicalRead+total_logical_writes,0)) as readoverwriteweight --,
                                     from Read_WriteIO order by overallreadweight desc
                                )
                                    select * from ReadOverWrite  '


  if ($auth -eq 's')
      {$ElasticAssessoutput= invoke-sqlcmd -TrustServerCertificate -serverInstance $dbserver -Database $dbname -user $User -query $ReadOverall -password $password 
       
      }
  else {$ElasticAssessoutput= invoke-sqlcmd -TrustServerCertificate -serverInstance $dbserver -Database $dbname  -query $ReadOverall 
   }

  $targetfile = "c:\rdstools\out\" + ($dbserver.replace('\', '~').Toupper()) + "_" + $dbtypeExt + "_" + $timestamp + "_Elasticache.csv"
 #  $ElasticAssessoutput | ConvertTo-Csv -NoTypeInformation | ForEach-Object { $_ -replace '"', '' } | out-file $targetfile
    $ElasticAssessoutput|Export-Csv -Path  $targetfile  | Format-Table  

 }
 function PreBabelfish {
 Param(
    [Parameter(Mandatory = $True)]$dbserver,
    [Parameter(Mandatory = $True)]$DBName,
    [Parameter(Mandatory = $False)]$User,
    [Parameter(Mandatory = $False)]$Password
  )
[System.Collections.ArrayList]$ArrayWithHeader2 = @()
$dbnamelist='select name as dbname,@@SERVERNAME as servername  from sys.databases where database_id>4'
if ($auth -eq 'W') {
             $dbname=invoke-sqlcmd -TrustServerCertificate -serverInstance $dbserver -Database master  -query $dbnamelist
             
                }
      else {
             $dbname=invoke-sqlcmd -TrustServerCertificate -serverInstance $dbserver -Database master  -query $dbnamelist -user $login -password $password 
            }
foreach ($db in $dbname) {
    $babelfishDBData = [PSCustomObject]@{
        DB = $db.dbname
        Extract   = "N"
    }
    $ArrayWithHeader2.Add($babelfishDBData) | Out-Null
}

$FilePath = "C:\rdstools\out\Babelfish_$dbserver.CSV"
# Export the summary data to CSV
$ArrayWithHeader2 | Export-Csv -Path $FilePath -NoTypeInformation


}
Function Babelfish
 {
  Param(
    [Parameter(Mandatory = $True)]$dbserver,
    [Parameter(Mandatory = $True)]$DBName,
    [Parameter(Mandatory = $False)]$User,
    [Parameter(Mandatory = $False)]$Password
  )
$script = 'C:\rdstools\babelfish.ps1'
$directoryPath = "c:\rdstools\out" #babelfish Files path
# Get all CSV files in the directory
$csvFiles = Get-ChildItem -Path $directoryPath -Filter "babelfish_$dbserver.csv"
# Loop through each CSV file
foreach ($file in $csvFiles) {
    # Process each CSV file
    # For example, reading the content of a CSV file
    $csvContent = Import-Csv -Path $file.FullName
    $filteredContent = $csvContent | Where-Object { $_.Extract -eq 'Y' }
    $DB=$filteredContent.DB
    if ($DB)
    {    &$script -Databases $DB -Password $Password -servername $server  -username $login}


   $script = 'C:\rdstools\babelfish.ps1'
  &$script -Password $Password -servername $server  -username $login
  Set-Location -Path "C:\rdstools\BabelfishCompass\BabelfishCompass"
  cmd.exe -/c "C:\rdstools\BabelfishCompass\BabelfishCompass\BabelfishCompass.bat $server c:\RDSTools\out\babelfish\$server\*.sql  -replace -reportoption xref -add"
  Set-Location -Path "C:\rdstools\"
   #$details=(get-content -path C:\RDSTools\out\report-report2-bbf.3.1.0-2023-May-28-00.09.59.html -TotalCount 498)
  #$details[-13..-1]
  }# if $DB
}
function Totalstorage{
$disks = Get-CimInstance -ClassName Win32_DiskDrive -ComputerName $dbserver
$totalStorage = 0
foreach ($disk in $disks) {
    $totalStorage += $disk.Size
}
$totalStorage = $totalStorage / 1GB
return $totalstorage
#Write-Host "Total Storage: $totalStorageGB GB"
}

Function DBC{
[System.Collections.ArrayList]$ArrayWithHeader = @()
$standalonecount = 0
  $Primarycount = 0
  $Secondarycount = 0
  $Readablecount = 0
  $standaloneSTcount = 0
  $PrimarySTcount = 0
  $SecondarySTcount = 0
  $EEVCPU = 0
  $STVCPU = 0
  $total = 0
  $TotalST = 0
  $row = 1
  $FilePath = "c:\rdstools\out\DBC.CSV"
  $dbcountDBC='select count(*) as dbcount  from sys.databases where database_id>4'
  $VMTYPE='seLECT  virtual_machine_type_desc AS VM_type FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE)'
  $totalstorage= totalstorage
 $DBCcsv = import-csv C:\RDSTools\out\RdsDiscovery.csv
    Foreach ($server in $DBCcsv) {
     $servername = $server.'Server Name'
    if ($servername)
    {
     
      $serverAG = $server.'Always ON AG enabled'
      $serverAGFCI = $server.'Always ON FCI enabled'
      $dbsize = $server.'Total DB Size in GB'
      $ServerRole = $server.'server role desc'
      $servercpu = $server.'cpu'
      $servermemory = $server.'Memory'
      $serverDBsize = $server.'Total DB Size in GB'
      $serverEdition = $Server.'SQL Server Current Edition'
      $serverInstance = $server.'RDS Compatible'
      $serverEF = $server.'Enterprise Level Feature Used '
      $serverRDSInstance = $server.'Instance Type'
      $serverRDSInstance = $serverRDSInstance
      $serverRDSInstance = $serverRDSInstance.TrimEnd()
       if (($serverAG -eq 'N') -and ($serverAGFCI -eq 'N'))
        { $isserverpartofcluster= 'N' }
        else {$isserverpartofcluster= 'Y' }

      if ($auth -eq 'W') {
             $dbCcount=invoke-sqlcmd -TrustServerCertificate -serverInstance $servername -Database master  -query $dbcountDBC 
             $DBCVMTYPE=invoke-sqlcmd -TrustServerCertificate -serverInstance $servername -Database master  -query $VMTYPE
                }
      else {
             $dbCcount=invoke-sqlcmd -TrustServerCertificate -serverInstance $servername -Database master  -query $dbcountDBC -user $login -password $password 
             $DBCVMTYPE=invoke-sqlcmd -TrustServerCertificate -serverInstance $servername -Database master  -query $VMTYPE  -user $login -password $password 
            }
      $DBCVMTYPE=$DBCVMTYPE.VM_Type
      $dbcount=$dbCcount.dbcount
       if ($serverEF) 
         {$IsEEFeatureUsed='Y'}
         else {$IsEEFeatureUsed='N'}
      $serverreadReplica=$server.'Read Only Replica'
    } 
else { break} 
# Define the object to hold the summarized data
$summaryData = [PSCustomObject]@{
      ServerName=$servername 
      VCPU=$servercpu 
      Memory=$servermemory 
      Edition=$serverEdition 
      IsPartOfCluster=$isserverpartofcluster
      IsAlwaysonAG=$serverAG
      IsAlwaysonFCI=$serverAGFCI
      DBRole=$ServerRole
      IsReadReplica=$serverreadReplica 
      InstanceType=$serverRDSInstance
      'Optimized Instance Type'=''
      IsEEFeatureUsed=$IsEEFeatureUsed
      'DBSize(GB)'=$serverDBsize  
      'TotalStorage(GB)'=$totalstorage
      CpuUtilization=0  
      MemoryUtilization=0   
      NoOfDB=$dbcount
      VMType=$DBCVMTYPE
      EBSType=0
      IOPS=0
      Throughput=0
      Elasticach=''
      Source=$SQLServerLocation
}
$ArrayWithHeader.add($summarydata) | Out-Null
    }#foreach
# Define the file path
$FilePath = "C:\rdstools\out\DBC.CSV"

# Export the summary data to CSV
$ArrayWithHeader | Export-Csv -Path $FilePath -NoTypeInformation

# Optional: Output message confirming the export
#Write-Host "Data exported to $FilePath"


}#DBC

Function TCO {
  $standalonecount = 0
  $Primarycount = 0
  $Secondarycount = 0
  $Readablecount = 0
  $standaloneSTcount = 0
  $PrimarySTcount = 0
  $SecondarySTcount = 0
  $EEVCPU = 0
  $STVCPU = 0
  $total = 0
  $TotalST = 0
  $row = 1
  $FilePath = "c:\rdstools\out\TCO_Calculator_Business_Case_Tool.xlsx"
  try {
    $objExcel = New-Object -ComObject Excel.Application
    $WorkBook = $objExcel.Workbooks.Open("$FilePath")
    $ExcelWorkSheet = $workbook.Sheets.Item("Discovery-Input")
    $tcocsv = import-csv C:\RDSTools\out\RdsDiscovery.csv
    Foreach ($server in $tcocsv) {
      $servername = $server.'Server Name'
      $serverAG = $server.'Always ON AG enabled'
      $serverAGFCI = $server.'Always ON FCI enabled'
      $dbsize = $server.'Total DB Size in GB'
      $ServerRole = $server.'server role desc'
      $servercpu = $server.'cpu'
      $servermemory = $server.'Memory'
      $serverDBsize = $server.'Total DB Size in GB'
      $serverEdition = $Server.'SQL Server Current Edition'
      $serverInstance = $server.'RDS Compatible'
      $serverEF = $server.'Enterprise Level Feature Used '
      $serverRDSInstance = $server.'Instance Type'
      $serverRDSInstance = $serverRDSInstance
      $serverRDSInstance = $serverRDSInstance.TrimEnd()
      $row++
      if ($servername ) {
        if ($serveredition -match 'Enterprise Edition') {
          if ($server.'DB Role Desc' -like 'Standalone') {
            $standalonecount ++
            $total++
          }
          elseif ($server.'DB Role Desc' -like 'Primary') {
            $Primarycount ++
            $total++
          }
          elseif ($server.'DB Role Desc' -like 'Readable') {
            $Readablecount ++
            $total++
          }
          else { $Secondarycount ++ }
          $EEVCPU = $EEVCPU + $servercpu
        }
        else {
          if ($server.'DB Role Desc' -like 'Standalone') {
            $standaloneSTcount ++
            $TotalST++
          }
          elseif ($server.'DB Role Desc' -like 'Primary') {
            $PrimarySTcount ++
            $TotalST++
          }
          elseif ($server.'DB Role Desc' -like 'Secondary') {
            $SecondarySTcount ++
            $TotalST++
          }
          $STVCPU = $STVCPU + $servercpu
        }
        $ExcelWorkSheet.Cells.Item($row, 1) = $servername
        $ExcelWorkSheet.Cells.Item($row, 2) = $servercpu
        $ExcelWorkSheet.Cells.Item($row, 3) = $servermemory
        $ExcelWorkSheet.Cells.Item($row, 4) = $serverDBsize
        if ($serverEdition -match 'Enterprise')
        { $ExcelWorkSheet.Cells.Item($row, 5) = 'Enterprise' }
        elseif ($serverEdition -match 'Standard')
        { $ExcelWorkSheet.Cells.Item($row, 5) = 'Standard' }
        if (($serverAG -eq 'N') -and ($serverAGFCI -eq 'N'))
        { $ExcelWorkSheet.Cells.Item($row, 6) = 'N' }
        Else { $ExcelWorkSheet.Cells.Item($row, 6) = 'Y' }
        $ExcelWorkSheet.Cells.Item($row, 7) = $serverAGFCI
        $ExcelWorkSheet.Cells.Item($row, 8) = $serverAG
        $ExcelWorkSheet.Cells.Item($row, 9) = $ServerRole
        if ($ServerRole -eq 'Readable') {
          $ExcelWorkSheet.Cells.Item($row, 10) = 'Y'
          $ExcelWorkSheet.Cells.Item($row, 9) = 'Secondary'
        }
        else { $ExcelWorkSheet.Cells.Item($row, 10) = 'N' }
        $ExcelWorkSheet.Cells.Item($row, 11) = $serverRDSInstance
        $ExcelWorkSheet.Cells.Item($row, 12) = 100
        if ($serveref )
        { $ExcelWorkSheet.Cells.Item($row, 13) = 'Y' }
        else { $ExcelWorkSheet.Cells.Item($row, 13) = 'N' }
        $ExcelWorkSheet.Cells.Item($row, 14) = $serverRDSInstance
      }
    }#foreach
    $workbook.Close($true)
  }#try
  catch {
    Write-Host 'Excel Sheet has not been detected on this Machine ,TCO will not be updated' -ForegroundColor Magenta
  }
}
Function Get-ExecutiveSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNull()]
        [PSCustomObject]$Report,
        
        [Parameter(Mandatory = $false)]
        [string]$OutputPath = "C:\RDSTools\out\RDSDiscoveryreport.html"
    )

    begin {
        $styles = @"
<style>
    body {
        background-color: #f5f5f5;
        font-family: Arial, sans-serif;
        margin: 20px;
        font-size: 12px;
    }
    .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 10px;
    }
    h1, h2 {
        background-color: #0066cc;
        color: white;
        text-align: center;
        padding: 12px;
        border-radius: 5px;
        margin-bottom: 20px;
        font-size: 16px;
        font-weight: 600;
    }
    h2 {
        background-color: #0066cc;
        margin-top: 25px;
    }
    .exec-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin: 15px 0;
        background: white;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .exec-table th, .exec-table td {
        padding: 8px;
        text-align: center;
        border: 1px solid #ddd;
        max-width: 150px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 12px;
    }
    .exec-table td:hover {
        white-space: normal;
        overflow: visible;
        position: relative;
        background-color: #e6f3ff;
        z-index: 1;
    }
    .exec-table th {
        background: #0066cc;
        color: white;
        font-weight: 600;
        font-size: 12px;
        position: sticky;
        top: 0;
        z-index: 2;
    }
    .exec-table tr:nth-child(odd) {
        background-color: #ffffff;
    }
    .exec-table tr:nth-child(even) {
        background-color: #f0f7ff;
    }
    .exec-table tr:hover {
        background-color: #e6f3ff;
    }
    .server-section {
        background: white;
        margin-bottom: 15px;
        border-radius: 4px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        overflow: hidden;
        border: 1px solid #e0e0e0;
    }
    .server-header {
        background: #0066cc;
        color: white;
        padding: 8px 15px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 600;
        font-size: 12px;
    }
    .server-header:hover {
        background: #0052a3;
    }
    .server-details {
        display: none;
        padding: 0;
        background-color: #ffffff;
    }
    .detail-row {
        display: flex;
        padding: 8px 15px;
        border-bottom: 1px solid #e0e0e0;
        transition: background-color 0.2s;
        font-size: 12px;
    }
    .detail-row:nth-child(odd) {
        background-color: #ffffff;
    }
    .detail-row:nth-child(even) {
        background-color: #f0f7ff;
    }
    .detail-row:hover {
        background-color: #e6f3ff;
    }
    .detail-row:last-child {
        border-bottom: none;
    }
    .detail-label {
        width: 180px;
        font-weight: 600;
        color: #0066cc;
    }
    .detail-value {
        flex: 1;
        color: #333;
    }
    .timestamp {
        text-align: center;
        color: #666;
        font-style: italic;
        margin-top: 15px;
        padding: 8px;
        background: white;
        border-radius: 4px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        font-size: 11px;
    }
    .arrow {
        transition: transform 0.3s;
    }
    .status-indicator {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 10px;
        font-size: 11px;
        font-weight: 600;
    }
    .Yes {
        background-color: #4CAF50;
        color: white;
    }
    .No {
        background-color: #f44336;
        color: white;
    }
    .section-separator {
        height: 1px;
        margin: 20px 0;
        background: #0066cc;
        opacity: 0.1;
    }
</style>
<script>
    function toggleDetails(elementId) {
        var element = document.getElementById(elementId);
        var arrow = element.previousElementSibling.getElementsByClassName('arrow')[0];
        
        if (element.style.display === 'block') {
            element.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
        } else {
            element.style.display = 'block';
            arrow.style.transform = 'rotate(180deg)';
        }
    }
</script>
"@

        $html = @"
<!DOCTYPE html>
<html>
<head>
    <title>SQL Server Discovery Report</title>
    $styles
</head>
<body>
    <div class="container">
        <h1>SQL Server Discovery Report</h1>
        <table class="exec-table">
            <tr>
                <th>Server Name</th>
                <th>SQL Edition</th>
                <th>VCPU</th>
                <th>Memory</th>
                <th>DB Size (GB)</th>
                <th>Instance Type</th>
                <th>RDS</th>
                <th>RDS Custom</th>
                <th>EC2</th>
                <th>Enterprise Features Used</th>
            </tr>
"@
    }

    process {
        try {
            # Add executive summary rows
            foreach ($server in $Report) {
                $html += @"
                <tr>
                    <td>$($server.'server name')</td>
                    <td>$($server.'SQL Server Current Edition')</td>
                    <td>$($server.'CPU')</td>
                    <td>$($server.'Memory')</td>
                    <td>$($server.'Total DB Size in GB')</td>
                    <td>$($server.'Instance Type')</td>
                    <td><span class="status-indicator $($server.'RDS Compatible')">$($server.'RDS Compatible')</span></td>
                    <td><span class="status-indicator $($server.'RDS Custom Compatible')">$($server.'RDS Custom Compatible')</span></td>
                    <td><span class="status-indicator $($server.'EC2 Compatible')">$($server.'EC2 Compatible')</span></td>
                    <td>$($server.'Enterprise Level Feature Used')</td>
                </tr>
"@
            }

            $html += @"
            </table>
            <div class="section-separator"></div>
            <h2>Detailed Server Information</h2>
"@

            # Add detailed sections
            $serverCount = 0
            foreach ($server in $Report) {
                $serverCount++
                $serverId = "details$serverCount"
                $html += @"
                <div class="server-section">
                    <div class="server-header" onclick="toggleDetails('$serverId')">
                        <div>
                            <span>$($server.'server name')</span>
                        </div>
                        <span class="arrow">▼</span>
                    </div>
                    <div class="server-details" id="$serverId">
                        <div class="detail-row">
                            <div class="detail-label">SQL Server Edition</div>
                            <div class="detail-value">$($server.'SQL Server Current Edition')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">VCPU</div>
                            <div class="detail-value">$($server.'CPU')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Memory</div>
                            <div class="detail-value">$($server.'Memory')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Total DB Size (GB)</div>
                            <div class="detail-value">$($server.'Total DB Size in GB')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Instance Type</div>
                            <div class="detail-value">$($server.'Instance Type')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Server Role</div>
                            <div class="detail-value">$($server.'Server Role Desc')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Read Only Replica</div>
                            <div class="detail-value">$($server.'Read Only Replica')</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">RDS Compatible</div>
                            <div class="detail-value">
                                <span class="status-indicator $($server.'RDS Compatible')">$($server.'RDS Compatible')</span>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">RDS Custom Compatible</div>
                            <div class="detail-value">
                                <span class="status-indicator $($server.'RDS Custom Compatible')">$($server.'RDS Custom Compatible')</span>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">EC2 Compatible</div>
                            <div class="detail-value">
                                <span class="status-indicator $($server.'EC2 Compatible')">$($server.'EC2 Compatible')</span>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Enterprise Features Used</div>
                            <div class="detail-value">$($server.'Enterprise Level Feature Used')</div>
                        </div>
                    </div>
                </div>
"@
            }

            $html += @"
            <div class="timestamp">Generated on: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>
        </div>
    </body>
</html>
"@

            $html | Out-File -FilePath $OutputPath -Encoding UTF8

            if (Test-Path $OutputPath) {
                Invoke-Item $OutputPath
            }
            else {
                Write-Error "Failed to create report at specified path: $OutputPath"
            }
        }
        catch {
            Write-Error "Error generating report: $_"
        }
    }
}


Function EC2Instance {
  Param(
    [Parameter(Mandatory = $True)]$EC2orRDS,
    [Parameter(Mandatory = $True)]$cpuonprem,
    [Parameter(Mandatory = $True)]$Memoryprem,
    [Parameter(Mandatory = $false)]$cpuutlization,
    [Parameter(Mandatory = $false)]$Memutlization
  )
  $file = import-csv "C:\RDSTools\in\AwsInstancesec2csv.csv"
  $rowMax = ($file).Count
  [System.Collections.ArrayList]$RDSArray = @()
  $objTemp = ''
  $RdsArray.add($RDSval) | Out-Null
  $val = $null
  for ($i = 2; $i -le $rowMax ; $i++) {
    $InstanceName = $file[$i]."instance type"
    $csvmemory = $file[$i].memory
    $csvvcpu = $file[$i].vcpu
    # if ([int]$csvvcpu  -ge [int]$cpuonprem -and $InstanceName -like "m6i*" )
    if ([int]$csvvcpu -ge [int]$cpuonprem -and $csvvcpu -lt [int]$cpuonprem ) {
      $RDSval = [pscustomobject]@{'InstanceName' = $InstanceName }
      $RDSArray.add($RDSval) | Out-Null
      $val = $null
      $RDSInstance = $RDSArray.instancename
      # $RDSInstance= $RDSArray.instancename| Select-Object -Unique|where {$_ -like "m6i*" }
      break
    }
  }
  #}
  $RDSInstance = ($RDSInstance -join ",")
  $RDSInstance
}#function EC2Instance
Function RDSInstance {
  Param(
    [Parameter(Mandatory = $True)]$EC2orRDS,
    [Parameter(Mandatory = $True)]$cpuonprem,
    [Parameter(Mandatory = $True)]$Memoryprem,
    [Parameter(Mandatory = $false)]$cpuutlization,
    [Parameter(Mandatory = $false)]$Memutlization
  )
  $class = ''
  $RDSInstance = ''
  $rdsval = ''
  if ($SqlEditionProduct.edition -like 'Enterprise Edition*')
  { $edition = 'EE' }
  else { $edition = 'SE' }  
  $version = $SqlEditionProduct.productversion.substring(0, 2)
  if ($version -eq '16') {
    $version = '16'
  }
  if ($Memoryprem -gt '1025') { $Memoryprem = 1025 }
  $cpuonprem = [math]::ceiling($cpuonprem / 4)
  if ($Memoryprem -lt '1025') {
    if ($cpuonprem -ge 25)
    { $class = '32xlarge' }
    if ($cpuonprem -le 24 -and $cpuonprem -gt 16)
    { $class = '24xlarge' }
    if ($cpuonprem -le 16 -and $cpuonprem -gt 12)
    { $class = '16xlarge' }
    if ($cpuonprem -le 12 -and $cpuonprem -gt 8)
    { $class = '12xlarge' }
    if ($cpuonprem -le 8 -and $cpuonprem -gt 4)
    { $class = '8xlarge' }
    if ($cpuonprem -le 4 -and $cpuonprem -gt 2)
    { $class = '4xlarge' }
    if ($cpuonprem -le 2 -and $cpuonprem -gt 1)
    { $class = '2xlarge' }
    if ($cpuonprem -le 1 )
    { $class = 'xlarge' }
    if ($cpuonprem -eq 0  )
    { $class = 'large' }
  }
  if ($cpuutlization -ge '80' -and $Memutlization -ge '80') {
    $CLASS = switch ($class) {
      '2Xlarge' { '4xlarge' }
      '4Xlarge' { '8xlarge' }
      '8Xlarge' { '12xlarge' }
      '12Xlarge' { '16xlarge' }
      '16Xlarge' { '24xlarge' }
      '24Xlarge' { '32xlarge' }
      '32Xlarge' { '32xlarge' }
    }
    $type = 'M'
  }
  elseif ($cpuutlization -ge '80' -and $Memutlization -le '80') {
    $CLASS = switch ($class) {
      '2Xlarge' { '4xlarge' }
      '4Xlarge' { '8xlarge' }
      '8Xlarge' { '12xlarge' }
      '12Xlarge' { '16xlarge' }
      '16Xlarge' { '24xlarge' }
      '24Xlarge' { '32xlarge' }
      '32Xlarge' { '32xlarge' }
    }
    $type = 'G' 
  }
  elseif ($cpuutlization -le '80' -and $Memutlization -ge '80') {
    $type = 'M' 
  }
  elseif ($cpuutlization -lt '50' -and $Memutlization -lt '50') {
    #scale Down.  
     if ($class -ne 'Xlrage') {
    $CLASS = switch ($class) {
      '2Xlarge' { 'xlarge' }
      '4Xlarge' { '2xlarge' }
      '8Xlarge' { '4xlarge' }
      '12Xlarge' { '8xlarge' }
      '16Xlarge' { '12xlarge' }
      '24Xlarge' { '16xlarge' }
      '32Xlarge' { '24xlarge' }
    }
  }
  $type = 'G' 
}
else { $type = 'G' }
if ($Memoryprem -ge 1025 ) {
  $class = '32xlarge'
}
$file = import-csv "C:\RDSTools\in\AwsInstancescsv.csv"
$rowMax = ($file).Count
[System.Collections.ArrayList]$RDSArray = @()
$objTemp = ''
$RdsArray.add($RDSval) | Out-Null
$val = $null
for ($i = 2; $i -le $rowMax ; $i++) {
  $InstanceName = $file[$i]."instance type"
  $csvversion = $file[$i].version
  $csvedition = $file[$i].edition
  $csviops = [int]$file[$i].iops
  $csvthroughput = [int]$file[$i].throughput
  if ($InstanceName -like "*.$class*" -and $csvedition -eq $edition -and $csvversion -match $version ) {
    $RDSval = [pscustomobject]@{'InstanceName' = $InstanceName; 'Version' = $version; 'Edition' = [string]$edition }
    $RDSArray.add($RDSval) | Out-Null
    $val = $null
  }
}
if ($Memoryprem -le 1024) {
  if ($type -eq 'M') {      
    $RDSInstance = $RDSArray.instancename | Select-Object -Unique | Where-Object { $_ -notlike "db.m*" -and $_ -notlike "db.r3*" -and $_ -notlike "db.r4*" -and $_ -notlike "db.t3*" -and $_ -notlike "db.x1*" -and $_ -notlike "db.x1e*" }
  }
  elseif ($type -eq 'G') {
    $RDSInstance = $RDSArray.instancename | Select-Object -Unique | Where-Object { $_ -like "db.m*" }#-and $_ -notlike "db.r3*" -and $_  -notlike "db.r4*" -and $_ -notlike "db.t3*"}
  }
}
Elseif ($Memoryprem -gt 1024) {
  $RDSInstance = $RDSArray.instancename | Select-Object -Unique | Where-Object { $_ -like "db.x*" }
}
$RDSInstance = ($RDSInstance -join ",")
$instance = $RDSInstance.split(",")
$RDSInstance = $instance[0]
$RDSInstance
}#rdsinstance.

function SqlserverDiscovery {
  $sqlVE = 'select SERVERPROPERTY(''Edition'') AS Edition ,SERVERPROPERTY (''productversion'') AS ProductVersion,SERVERPROPERTY (''IsClustered'') as [Clustered]'
  if ($auth -eq 'W') {
    $SQLVEresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master  -query $sqlVE 
  }
  else {
    $SQLVEresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master -user $login -query $sqlVE -password $password 
  }
  return $sqlveresult
}#sqlserverdiscovery Function
function L200Discovery {
  Param(
    [Parameter(Mandatory = $True)]$dbserver,
    [Parameter(Mandatory = $True)]$DBName,
    [Parameter(Mandatory = $false)]$User,
    [Parameter(Mandatory = $false)]$password
  )
  if ($auth -eq 'W') {
    $sqlLfeatures = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master  -inputfile "C:\RDSTools\In\LimitationQueries.sql"  
  }
  else {
    $sqlLfeatures = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master -user $login  -inputfile "C:\RDSTools\In\LimitationQueries.sql" -password $password 
  }
  return $sqlLfeatures
}
function Test-SQLConnection {  
  [OutputType([bool])]
  Param
  (
    [Parameter(Mandatory = $true,
      ValueFromPipelineByPropertyName = $true,
      Position = 0)]
    $ConnectionString
  )
  try {
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
    $sqlConnection.Open();
    $sqlConnection.Close();
    return $true;
  }
  catch {
    return $false;
  }
}
# Main  Function ****************************************************************************************************************
if ($options -eq 'help') {
  write-host " To run the Tool you can either run it using Sql Server Authentication or windows authentication"
  Write-host "   For Sql Server Auth :"
  Write-host "     Rdsdiscoveryguide.exe -Auth s -login ''login'' -password ''password'' -sqlserverendpoint C:\RDSTools\in\server.txt" -ForegroundColor Green
  Write-host "   For Windows authentication"
  Write-host "     Rdsdiscoveryguide.exe -Auth W -sqlserverendpoint C:\RDSTools\in\server.txt" -ForegroundColor Green
  Write-host " By the default the tool will run without RDS Recommendation"
  write-host " To include recommendation run this tool with -option rds"
  Write-host " i.e Rdsdiscoveryguide.exe -Auth W -sqlserverendpoint C:\RDSTools\in\server.txt -options rds" -ForegroundColor Green
  Write-host " OR instead of the exe you can run the bat file "
  Write-host " Rdsdiscovery.bat -Auth s -login ''login'' -password ''password'' -sqlserverendpoint C:\RDSTools\in\server.txt" -ForegroundColor green
  exit
}
[System.Collections.ArrayList]$RDSArray = @()
[System.Collections.ArrayList]$ArrayWithHeader = @()
$RdsArray.add($RDSval) | Out-Null
$val = $null
$timestamp = Get-Date -Format "MMddyyyyHHmm "
$RDSval = ''
$rdsCustomcompatible = 'Y'
$rdscompatible = 'Y'
$EC2orRDS = ''
$cpuonprem = ''
$Memoryprem = ''
$objTemp = ''
$copywrite = [char]0x00A9
Write-Host 'RdsDiscovery Ver 4.00' $copywrite 'BobTheRdsMan.' -ForegroundColor Magenta
Write-Host 'Disclaimer: This Tool is not created or supported by AWS. ' -ForegroundColor Magenta
Write-Host 'Although it is a low risk please make sure  you test in dev before running it in prod.' -ForegroundColor Magenta
Write-Host '  For Help run the tool with -options help i.e Rdsdiscoveryguide.bat -options help' -ForegroundColor green
Write-Host 'To report Bugs or issues please email bacrifai@amazon.com'-ForegroundColor Magenta
$CpuSql = "SELECT cpu_count AS CPU FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE);"
$MemSql = "SELECT  convert(int,value_in_use)/1024 as MaxMemory FROM sys.configurations
WHERE name like 'max server memory%' "
$FileExists = Test-Path -Path $SqlserverEndpoint
if (-Not $FileExists) {
  Write-host " Input file  Doesn't exists, Make sure you update the server.txt in Rdstools\in" -ForegroundColor red
  exit
} # $fileexists
# L100Questions

$SqlserverEndpoint = Get-Content $SqlserverEndpoint
foreach ($server in $SqlserverEndpoint) {
  $rdscompatible = 'Y'
  $rdsCustomcompatible = 'Y'
  if ($auth -eq 'W') {
    $Conn = "Data Source=$server;database=master;Integrated Security=True;"
  }
  else {
    $Conn = "Data Source=$server;User ID=$login;Password=$password;"
  }
  if (Test-SqlConnection $Conn) {
    if ($auth -eq 'W' ) {
      $L200Result = L200Discovery -dbserver $server -DBName master
      $SqlEditionProduct = SqlserverDiscovery -dbserver $server -DBName master
      $cpuresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master  -query $CpuSql 
      $Memresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master  -query $Memsql    
      ElasticacheAssessment   -dbserver $server -DBName master         
      if ($babelfish -ne 'Y'){PreBabelfish -dbserver $server -DBName master  }
        }
    Else {
      $L200Result = L200Discovery -dbserver $server -DBName master -user $login -password $password
      $SqlEditionProduct = SqlserverDiscovery -dbserver $server -DBName master -user $login -password $password
      $cpuresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master -user $login -query $CpuSql -password $password 
      $Memresult = invoke-sqlcmd -TrustServerCertificate -serverInstance $server -Database master -user $login -query $Memsql -password $password 
       ElasticacheAssessment -dbserver  $server -DBNAME master -user $login  -password $password 
       if ($babelfish -ne 'Y'){PreBabelfish -dbserver $server -DBName master  -user $login -password $password }
    }
    #$options=Get-Content $options
    foreach ($option in $options) {
      If ($option -eq 'RDS') {
        $Ec2orrds = 'RDS'
        $Instance = Rdsinstance $Ec2orrds $cpuresult.CPU $memresult.MAXMemory 50 50
      }
      if ($option -eq 'TCO') {
        $Ec2orrds = 'RDS'
        $Instance = Rdsinstance $Ec2orrds $cpuresult.CPU $memresult.MAXMemory 50 50
        Tco
      }
      if ($option -eq 'TCOonly') {
        Tco
        exit
      }
    }#foreach option
    if ($babelfish -eq 'Y') {
      Babelfish -dbserver $server -DBName master  -user $login -password $password
      #exit
    }
      if ($L200Result.dbcount -eq 'Y' -or $L200Result.islinkedserver -eq 'Y' -or $L200Result.issqlTLShipping -eq 'Y' -or 
        $L200Result.isFilestream -eq 'Y' -or $L200Result.isResouceGov -eq 'Y' -or $L200Result.issqlTranRepl -eq 'Y' -or 
        $l200Result.isextendedProc -eq 'Y' -or $L200Result.istsqlendpoint -eq 'Y' -or $L200Result.ispolybase -eq 'Y' -or
         $L200Result.isfiletable -eq 'Y' -or $L200Result.isbufferpoolextension -eq 'Y' -or $L200Result.isstretchDB -eq 'Y' -or 
         $L200Result.UsedSpaceGB -eq 'Y' -or $L200Result.istrustworthy -eq 'Y' -or $L200Result.Isservertrigger -eq 'Y' -or 
         $L200Result.isRMachineLearning -eq 'Y' -or $L200Result.ISPolicyBased -eq 'Y' -or $L200Result.isdqs -eq 'Y' -or 
         $L200Result.isCLREnabled -eq 'Y' -or $L200Result.isOnlinIndexes -eq 'Y')
      { $rdscompatible = 'N' }
    else { $rdscompatible = 'Y' }
    if ($SQLServerLocation -eq 1 )
    { $SQLServerLocation = 'ONPrem' }
    elseif ($SQLServerLocation -eq 2 )
    { $SQLServerLocation = 'EC2' }
    elseif ($SQLServerLocation -eq 3 )
    { $SQLServerLocation = 'Another Cloud' }
    if ( $L200Result.UsedSpaceGB -gt 14901.161) {
      #$rdscompatible = 'N'
      $rdsCustomcompatible = 'N'
      if ($options -eq 'RDS') {
        $Ec2orrds = 'Ec2'
        #$Instance=EC2Instance  $Ec2orrds $cpuresult.CPU $memresult.MAXMemory 50 50
      }
    }
  $totalstorage= totalstorage
   if ($rdscompatible -eq 'N' -and $babelfish -ne 'Y') {
      $val = [pscustomobject]@{'Server Name' = $server;
        'SQL Server Current Edition' = $SqlEditionProduct.edition;
        'SQL Server current Version' = $SqlEditionProduct.productversion;
        'Sql server Source' = $L200Result.source;
        'SQL Server Replication' = [string]$L200Result.issqlTranRepl;
        'Heterogeneous linked server' = [string]$L200Result.islinkedserver;
        'Database Log Shipping ' = [string]$L200Result.issqlTLShipping ;
        'FILESTREAM' = [string]$L200Result.isFilestream;
        'Resource Governor' = [string]$L200Result.isResouceGov;
        'Service Broker Endpoints ' = [string]$L200Result.issqlServiceBroker;
        'Non Standard Extended Proc' = [string]$L200Result.isextendedProc;
        'TSQL Endpoints' = [string]$L200Result.istsqlendpoint;
        'PolyBase' = [string]$L200Result.ispolybase;
        'File Table' = [string]$L200Result.isfiletable;
        'buffer Pool Extension' = [string]$L200Result.isbufferpoolextension;
        'Stretch DB' = [string]$L200Result.isstretchDB;
        'Trust Worthy On' = [String]$L200Result.istrustworthy;
        'Server Side Trigger' = [string]$L200Result.Isservertrigger;
        'R & Machine Learning' = [string]$L200Result.isRMachineLearning;
        'Data Quality Services' = [string]$L200Result.isDQS;
        'Policy Based Management' = [string]$L200Result.ISPolicyBased;
        'CLR Enabled (only supported in Ver 2016)' = [String]$L200Result.isCLREnabled;
        'Free Check' = [string]$L200Result.isfree;
        'DB count Over 100' = [string]$L200Result.dbcount;
        'Total DB Size in GB' = [String]$L200Result.UsedSpaceGB;
        'Total Storage(GB)' =[string] $totalstorage;
        'Always ON AG enabled' = [String]$L200Result.IsAlwaysOnAG;
        'Always ON FCI enabled' = [String]$L200Result.isalwaysonFCI;
        'Server Role Desc' = [string]$l200Result.DBRole;
        'Read Only Replica' = [String]$L200Result.IsReadReplica;
        'Online Indexes'=[String]$L200Result.isOnlinIndexes;
        'RDS Compatible' = $rdscompatible;
        'RDS Custom Compatible' = $rdsCustomcompatible;
        'EC2 Compatible' = 'Y';
        'Elasticache'= [string]$L200Result.ISElasticache;
        'Enterprise Level Feature Used' = [string]$L200Result.isEEFeature;
        'Memory' = $memresult.MAXMemory;
        'CPU' = $cpuresult.CPU;
        'Instance Type' = [string]$instance;
        'Note' = [string]'***** Plase Note That the Discovery Tool will only detect if a feature is turned on or not ,a feature may be turned on but not used .Use the Queries found in the IN directory to investigate'
      } #@val
          $ArrayWithHeader.add($val) | Out-Null
          $val = $null
    }#if $Rdscompatible
    elseif($rdscompatible -eq 'Y' -and $babelfish -ne 'Y')  {
      $val = [pscustomobject]@{'Server Name' = $server; 'Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?' = [string]$SQLServerLocation;
        'Do you currently own any SQL Server licenses that you could bring to the Cloud?Y\N' = [string]$License;
        'Are you using perpetual license and paying software assurance? Y\N' = [string]$perpetual;
        'Are you using subscription license and paying subscription cost? Y\N' = [string]$subscription;
        'will you be open to consider using a managed service with License Included, assuming we could make the economics work? Y\N' = [string]$BYOL;
        'Do you see value of having AWS manage your SQL databases? Y\N' = [string]$RDSValue;
        'Then what are the primary motivations (e.g. cost saving, staff productivity, operational resilience, business agility)?' = [string]$RdsMotivation;
        'What is the timeline for SQL Server migration to the Cloud? (Please input an estimated target date in No of Months )' = [string]$migrationtimeframe;
        'SQL Server Current Edition' = $SqlEditionProduct.edition;
        'SQL Server current Version' = $SqlEditionProduct.productversion;
        'Sql server Source' = $L200Result.source;
        'SQL Server Replication' = [string]$L200Result.issqlTranRepl;
        'Heterogeneous linked server' = [string]$L200Result.islinkedserver;
        'Database Log Shipping ' = [string]$L200Result.issqlTLShipping ;
        'FILESTREAM' = [string]$L200Result.isFilestream;
        'Resource Governor' = [string]$L200Result.isResouceGov;
        'Service Broker Endpoints ' = [string]$L200Result.issqlServiceBroker;
        'Non Standard Extended Proc' = [string]$L200Result.isextendedProc;
        'TSQL Endpoints' = [string]$L200Result.istsqlendpoint;
        'PolyBase' = [string]$L200Result.ispolybase;
        'File Table' = [string]$L200Result.isfiletable;
        'buffer Pool Extension' = [string]$L200Result.isbufferpoolextension;
        'Stretch DB' = [string]$L200Result.isstretchDB;
        'Trust Worthy On' = [String]$L200Result.istrustworthy;
        'Server Side Trigger' = [string]$L200Result.Isservertrigger;
        'R & Machine Learning' = [string]$L200Result.isRMachineLearning;
        'Data Quality Services' = [string]$L200Result.isDQS;
        'Policy Based Management' = [string]$L200Result.ISPolicyBased;
        'CLR Enabled (only supported in Ver 2016)' = [String]$L200Result.isCLREnabled;
        ' Free Check' = [string]$L200Result.isfree;
        'DB count Over 100' = [string]$L200Result.dbcount;
        'Total DB Size in GB' = [String]$L200Result.UsedSpaceGB;
        'Always ON AG enabled' = [String]$L200Result.IsAlwaysOnAG;
        'Always ON FCI enabled' = [String]$L200Result.isalwaysonFCI;
        'Server Role Desc' = [string]$l200Result.DBRole;
        'Read Only Replica' = [String]$L200Result.IsReadReplica;
        'Online Indexes'=[String]$L200Result.isOnlinIndexes;
        'RDS Compatible' = $rdscompatible;
        'RDS Custom Compatible' = $rdsCustomcompatible;
        'EC2 Compatible' = 'Y';
        'Elasticache'= [string]$L200Result.ISElasticache;
        'Enterprise Level Feature Used' = [string]$L200Result.isEEFeature;
                'Memory' = $memresult.MAXMemory;
        'CPU' = $cpuresult.CPU;
        'Instance Type' = [string]$instance
      } #@val
         $ArrayWithHeader.add($val) | Out-Null
         $val = $null
    }#else $Rdscompatible
    #$ArrayWithHeader.add($val) | Out-Null
    #$val = $null
   
  }#if testconnection
  else {
    #write-host $server
    write-host "***** Can't connect to $server"
  }#else
  if ($babelfish -ne 'Y')
  {  $ArrayWithHeader | export-Csv -LiteralPath "C:\RDSTools\out\RdsDiscovery.csv" -NoTypeInformation -Force}
  #} #if babelfish ne Y
}#foreach $server
if ($babelfish -ne 'Y')
{ 
Get-ExecutiveSummary $ArrayWithHeader
$val = [pscustomobject]@{'Server Name' = '' }
$ArrayWithHeader.add($val) | Out-Null
$val = [pscustomobject]@{'Where is the current SQL Server workload running on, OnPrem[1], EC2[2], or another Cloud[3]?' = '****Note: Instance recommendation is general purpose based on server CPU and Memory capacity , and it is matched by CPU ' }
$ArrayWithHeader.add($val) | Out-Null
$val = $null
$ArrayWithHeader | export-Csv -LiteralPath "C:\RDSTools\out\RdsDiscovery.csv" -NoTypeInformation -Force
DBC
}