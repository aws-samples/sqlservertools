﻿Param (
  [Parameter()][string]$auth,
  [Parameter()][string]$login,
  [Parameter()][string]$password,
  [Parameter()]$sqlserverendpoint,
  [Parameter()]$sa = 'sa',
  [parameter()][String] $AdminDB = 'msdb'
)
function Test-SQLConnection {  
  [OutputType([bool])]
  Param
  (
    [Parameter(Mandatory = $true,
      ValueFromPipelineByPropertyName = $true,
      Position = 0)]
    $ConnectionString
  )
  try {
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
    $sqlConnection.Open();
    $sqlConnection.Close();
    return $true;
  }
  catch {
    return $false;
  }
}#test-sqlConnection
$outputDirectory = "c:\rdstools\out"
$queriesDirectory="c:\rdstools\in\queries"
# Check which First Responder Kit script to run
$scripts = @(
    @{ Name = "sp_Blitz"; CommandText = "EXEC dbo.sp_Blitz" },
    @{ Name = "sp_BlitzIndex"; CommandText = "EXEC dbo.sp_BlitzIndex" },
    @{ Name = "sp_BlitzCache"; CommandText = "EXEC dbo.sp_BlitzCache" },
    @{ Name = "sp_BlitzFirst"; CommandText = "EXEC dbo.sp_BlitzFirst" }
)

$selectedScript = $null
while ($selectedScript -eq $null) {
    Write-Host "Please select a First Responder Kit script to run:"
    for ($i = 0; $i -lt $scripts.Count; $i++) {
        Write-Host "[$($i+1)] $($scripts[$i].Name)"
    }
    $selection = Read-Host "Enter the number of the script to run"
    if ([int]$selection -ge 1 -and [int]$selection -le $scripts.Count) {
        $selectedScript = $scripts[[int]$selection-1]
    } else {
        Write-Host "Invalid selection. Please try again."
    }
}

### adding the multi server execution

$SqlserverEndpoint = Get-Content $SqlserverEndpoint
foreach ($server in $SqlserverEndpoint) {
  if ($auth -eq 'W') {
    $Conn = "Data Source=$server;database=master;Integrated Security=True;"
  }
  else {
    $Conn = "Data Source=$server;User ID=$login;Password=$password;"
  }
  if (Test-SqlConnection $Conn) {

# Check if the selected script is present in the database
if ($auth -eq 's')
{
$result = Invoke-Sqlcmd -ServerInstance $server -Database $admindb -Username $login -Password $password -Query "IF OBJECT_ID('dbo.$($selectedScript.Name)') IS NULL SELECT 1 ELSE SELECT 0"
}
Else 
{
$result = Invoke-Sqlcmd -ServerInstance $server -Database $admindb -Query "IF OBJECT_ID('dbo.$($selectedScript.Name)') IS NULL SELECT 1 ELSE SELECT 0"
}

if ($result.Column1 -eq 1) {
    Write-Host "The $($selectedScript.Name) stored procedure is not present in the database."
    Write-Host "Please run the script in $queriesDirectory\$($selectedScript.Name).sql to install it."
  
} # if #result
# Run the selected First Responder Kit script
elseif ($result.Column1 -eq 0) 
{
    if ($auth -eq 's')
            {$output = Invoke-Sqlcmd -ServerInstance $server -Database $admindb -Username $login -Password $password -Query $selectedScript.CommandText
            }
    Else 
            {$output = Invoke-Sqlcmd -ServerInstance $server -Database $admindb  -Query $selectedScript.CommandText
            }


# Analyze the output of the script
$issues = $output | Select-Object Priority, FindingsGroup, Finding, URL, Details

# Sort the issues by priority
$issues = $issues | Sort-Object -Property Priority

# Generate the report
$reportFileText = Join-Path -Path $outputDirectory -ChildPath "$($server)_$($selectedScript.Name)_issues_report.txt"
$reportFileHtml = Join-Path -Path $outputDirectory -ChildPath "$($server)_$($selectedScript.Name)_issues_report.html"

# Create the text report
$reportContent = ""

# Critical issues
$criticalIssues = $issues | Where-Object { $_.Priority -eq 1 }
if ($criticalIssues.Count -gt 0) {
    $reportContent += "Critical Issues:`n"
    foreach ($issue in $criticalIssues) {
        $reportContent += "- Finding: $($issue.Finding)`n"
        $reportContent += "  Findings Group: $($issue.FindingsGroup)`n"
        $reportContent += "  Details: $($issue.Details)`n"
        $reportContent += "  URL: $($issue.URL)`n`n"
    }
    $reportContent += "`n"
}

# High issues
$highIssues = $issues | Where-Object { $_.Priority -eq 2 }
if ($highIssues.Count -gt 0) {
    $reportContent += "High Issues:`n"
    foreach ($issue in $highIssues) {
        $reportContent += "- Finding: $($issue.Finding)`n"
        $reportContent += "  Findings Group: $($issue.FindingsGroup)`n"
        $reportContent += "  Details: $($issue.Details)`n"
        $reportContent += "  URL: $($issue.URL)`n`n"
    }
    $reportContent += "`n"
}

# Medium issues
$mediumIssues = $issues | Where-Object { $_.Priority -eq 3 }
if ($mediumIssues.Count -gt 0) {
    $reportContent += "Medium Issues:`n"
    foreach ($issue in $mediumIssues) {
        $reportContent += "- Finding: $($issue.Finding)`n"
        $reportContent += "  Findings Group: $($issue.FindingsGroup)`n"
        $reportContent += "  Details: $($issue.Details)`n"
        $reportContent += "  URL: $($issue.URL)`n`n"
    }
    $reportContent += "`n"
}

# Low issues
$lowIssues = $issues | Where-Object { $_.Priority -eq 4 }
if ($lowIssues.Count -gt 0) {
    $reportContent += "Low Issues:`n"
    foreach ($issue in $lowIssues) {
        $reportContent += "- Finding: $($issue.Finding)`n"
        $reportContent += "  Findings Group: $($issue.FindingsGroup)`n"
        $reportContent += "  Details: $($issue.Details)`n"
        $reportContent += "  URL: $($issue.URL)`n`n"
    }
    $reportContent += "`n"
}

# Save the text report
Out-File -FilePath $reportFileText -InputObject $reportContent -Encoding utf8

# Create the HTML report
$reportContentHtml = "<html><head><title>$($server) $($selectedScript.Name) Issues Report</title></head><body>"
$reportContentHtml += "<h1>$($server) $($selectedScript.Name) Issues Report</h1>"

# Critical issues
if ($criticalIssues.Count -gt 0) {
    $reportContentHtml += "<h2>Critical Issues</h2>"
    foreach ($issue in $criticalIssues) {
        $reportContentHtml += "<h3>Finding: $($issue.Finding)</h3>"
        $reportContentHtml += "<p>Findings Group: $($issue.FindingsGroup)</p>"
        $reportContentHtml += "<p>Details: $($issue.Details)</p>"
        $reportContentHtml += "<p>URL: <a href=""$($issue.URL)"">$($issue.URL)</a></p><hr>"
    }
}

# High issues
if ($highIssues.Count -gt 0) {
    $reportContentHtml += "<h2>High Issues</h2>"
    foreach ($issue in $highIssues) {
        $reportContentHtml += "<h3>Finding: $($issue.Finding)</h3>"
        $reportContentHtml += "<p>Findings Group: $($issue.FindingsGroup)</p>"
        $reportContentHtml += "<p>Details: $($issue.Details)</p>"
        $reportContentHtml += "<p>URL: <a href=""$($issue.URL)"">$($issue.URL)</a></p><hr>"
    }
}

# Medium issues
if ($mediumIssues.Count -gt 0) {
    $reportContentHtml += "<h2>Medium Issues</h2>"
    foreach ($issue in $mediumIssues) {
        $reportContentHtml += "<h3>Finding: $($issue.Finding)</h3>"
        $reportContentHtml += "<p>Findings Group: $($issue.FindingsGroup)</p>"
        $reportContentHtml += "<p>Details: $($issue.Details)</p>"
        $reportContentHtml += "<p>URL: <a href=""$($issue.URL)"">$($issue.URL)</a></p><hr>"
    }
}

# Low issues
if ($lowIssues.Count -gt 0) {
    $reportContentHtml += "<h2>Low Issues</h2>"
    foreach ($issue in $lowIssues) {
        $reportContentHtml += "<h3>Finding: $($issue.Finding)</h3>"
        $reportContentHtml += "<p>Findings Group: $($issue.FindingsGroup)</p>"
        $reportContentHtml += "<p>Details: $($issue.Details)</p>"
        $reportContentHtml += "<p>URL: <a href=""$($issue.URL)"">$($issue.URL)</a></p><hr>"
    }
}

$reportContentHtml += "</body></html>"

# Save the HTML report
Out-File -FilePath $reportFileHtml -InputObject $reportContentHtml -Encoding utf8

Write-Host "Reports saved to:"
Write-Host "- $reportFileText"
Write-Host "- $reportFileHtml"
}#test-serverconnection
}#elseif ($result.Column1 -eq 0)
else {
    #write-host $server
    write-host "***** Can't connect to $server"
  }#else
  }