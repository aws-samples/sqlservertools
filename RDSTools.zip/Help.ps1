﻿Param
(  [Parameter()][string]$customer
)

# Create a temporary directory to store the JSON files
#$tempDir = New-Item -ItemType Directory -Path "$env:TEMP\JSONFiles" -Force
$tempDir = 'C:\rdstools\out'
# Get all CSV files and filter them using Where-Object
$csvFiles = Get-ChildItem -Path $tempDir -Filter "*.csv" | Where-Object { 
    $_.Name -like "*_SQL_DBIO.csv" -or
    $_.Name -like "*_cpuinfo.csv" -or
    $_.Name -like "*_memcollection.csv" -or
    $_.Name -like "*_cpucollection.csv" -or
    $_.Name -like "rdsdiscovery.csv" -or
    $_.Name -like "SQLAssesmentOutput.csv"
    $_.Name -like "DBC.csv"
}

# Convert the CSV files to JSON
foreach ($csvFile in $csvFiles) {
    $jsonFile = Join-Path -Path $tempDir -ChildPath "$($csvFile.BaseName).json"
    Import-Csv -Path $csvFile.FullName | ConvertTo-Json | Out-File -FilePath $jsonFile
}

# Zip the JSON files
$zipFile = "$tempDir\$customer.zip"
Compress-Archive -Path "$tempDir\*.json" -DestinationPath $zipFile -Force

