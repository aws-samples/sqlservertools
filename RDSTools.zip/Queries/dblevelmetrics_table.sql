drop table DatabasePerformance
go
CREATE TABLE DatabasePerformance (
    DatabaseID INT,
    DBName NVARCHAR(255),
    DBBufferPages BIGINT,
    DBBufferMB DECIMAL(18,2),
    DBBufferPercent DECIMAL(5,2),
    SizeGB DECIMAL(18,4),
    TotalIops DECIMAL(18,2),
    Throughput DECIMAL(18,2),
    AverageTotalLatency DECIMAL(10,1),
    PRIMARY KEY (DatabaseID)
);


DECLARE @total_buffer INT;

SELECT @total_buffer = cntr_value
FROM sys.dm_os_performance_counters
WHERE [object_name] LIKE '%Buffer Manager%'
  AND counter_name = 'Database Pages';

;WITH DBSize AS (
    SELECT db_name(database_id) AS DBNAME,
           database_id,
           SUM(size * 8) / 1024 / 1024.0 AS Size
    FROM master.sys.master_files
    WHERE database_id > 4
    GROUP BY database_id
),
src AS (
    SELECT database_id, 
           db_buffer_pages = COUNT_BIG(*)
    FROM sys.dm_os_buffer_descriptors
    GROUP BY database_id
),
latency AS (
    SELECT DB_NAME(vfs.database_id) AS dbname,
           SUM(CAST((io_stall_read_ms + io_stall_write_ms) / (1.0 + num_of_reads + num_of_writes) AS NUMERIC(10,1))) AS [Average Total Latency]
    FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
    WHERE database_id > 4 
      AND database_id < 32760
    GROUP BY DB_NAME(vfs.database_id)
),
IOPs AS (
    SELECT Database_ID,
           isnull(SUM(TotalIOPs) / 60, 0) AS Max_IOPS,
           isnull((SUM(BRead + BWritten) / 60) / 1048576, 0) AS Max_Throughput
    FROM [msdb].[dbo].[SQL_DBIO]
    WHERE [TotalIOPs] > 0
    GROUP BY Database_ID
)

INSERT INTO DatabasePerformance( DatabaseID,DBName,DBBufferPages,DBBufferMB, DBBufferPercent,SizeGB,TotalIops,Throughput,AverageTotalLatency)

SELECT d.database_id,
       [db_name] = CASE s.[database_id] 
                   WHEN 32767 THEN 'Resource DB'
                   ELSE DB_NAME(s.[database_id]) 
                   END,
       db_buffer_pages,
       db_buffer_MB = db_buffer_pages / 128,
       db_buffer_percent = CONVERT(DECIMAL(6,3), db_buffer_pages * 100.0 / @total_buffer),
       d.Size,
       ISNULL(i.Max_IOPS, 0) AS TotalIops,
       ISNULL(i.Max_Throughput, 0) AS Throughput,
       l.[Average Total Latency]
FROM src s
LEFT JOIN DBSize d ON s.database_id = d.database_id
LEFT JOIN latency l ON d.database_id = DB_ID(l.dbname)
LEFT JOIN IOPs i ON DB_ID(l.dbname) = i.Database_ID
WHERE d.database_id IS NOT NULL
ORDER BY db_buffer_MB DESC;
select * from DatabasePerformance